# apply-seo.ps1
# Run from repo root. Creates new service pages, robots.txt, sitemap.xml and favicon.svg

$root = Get-Location

# Ensure services dir exists
$servicesDir = Join-Path $root 'frontend\services'
if (-not (Test-Path $servicesDir)) {
    New-Item -Path $servicesDir -ItemType Directory -Force | Out-Null
}

function Write-File($path, $content) {
    $dir = Split-Path $path -Parent
    if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
    $content | Set-Content -Path $path -Encoding UTF8
    Write-Host "Wrote $path"
}

# Loft Conversions
Write-File "$servicesDir\loft-conversions.html" @'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Loft Conversions | TradeMatch</title>
  <meta name="description" content="Loft conversions: guide, costs and trusted tradespeople. Get free quotes from local loft conversion specialists across the UK." />
  <link rel="canonical" href="https://www.tradematch.uk/services/loft-conversions" />
  <link rel="icon" href="/favicon.ico" />
</head>
<body>
  <header class="container">
    <a class="logo" href="/">TradeMatch</a>
  </header>

  <main class="container content-block">
    <h1>Loft Conversions</h1>

    <p>Loft conversions are a popular way to add living space without extending the footprint of your home. On TradeMatch, you can connect with local loft conversion contractors who offer design, structural work, insulation, stairs and finishing. Whether you're planning a dormer loft, mansard conversion or rooflight solution, our network includes professionals who specialise in loft conversions across the UK.</p>

    <h2>Why choose a loft conversion?</h2>
    <p>A loft conversion typically delivers high value for homeowners — increased living space, improved property value and minimal disruption to garden or external footprint. Typical uses include extra bedrooms, home offices, or en-suite additions.</p>

    <h2>What to expect</h2>
    <p>Expect site surveys, structural design and planning checks where necessary. Contractors often provide a phased quote: survey & design, structural works and finishings. Timelines can vary between 4–12 weeks depending on complexity.</p>

    <h2>Get the best quotes</h2>
    <p>To get accurate quotes, include floor area, desired layout, measurements and photos. TradeMatch allows you to upload photos and project details and receive multiple quotes from verified loft conversion specialists.</p>

    <h2>Next steps</h2>
    <p>Ready to explore loft conversions? Post your job to receive free quotes from tradespeople near you and compare their past work, reviews and pricing.</p>

    <div class="cta">
      <a class="btn btn-primary" href="/get-quotes.html">Get Free Quotes</a>
    </div>
  </main>

  <footer class="container">
    <p>Serving homeowners across England, Scotland & Wales</p>
  </footer>
</body>
</html>
'@

# Home Extensions
Write-File "$servicesDir\home-extensions.html" @'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Home Extensions | TradeMatch</title>
  <meta name="description" content="Home extensions: find reliable builders and architects. Get free quotes for house extensions across the UK." />
  <link rel="canonical" href="https://www.tradematch.uk/services/home-extensions" />
  <link rel="icon" href="/favicon.ico" />
</head>
<body>
  <header class="container">
    <a class="logo" href="/">TradeMatch</a>
  </header>

  <main class="container content-block">
    <h1>Home Extensions</h1>

    <p>Home extensions provide the extra space families need — extended kitchens, dining rooms or ground-floor expansions. TradeMatch connects you with builders, architects and project managers experienced in extensions, ensuring planning, structural works and finishes are managed professionally.</p>

    <h2>Types of extensions</h2>
    <p>Common types include single-storey rear extensions, side returns, wrap-around extensions and two-storey additions. Each project has different planning and structural requirements — our local pros can advise on cost-effective options.</p>

    <h2>How to get accurate quotes</h2>
    <p>Share existing plans or sketches, proposed layout, and any known planning constraints. Tradespeople will typically provide site visits before finalising budgets.</p>

    <h2>Ready to start?</h2>
    <p>Post your extension project and receive multiple quotes from local contractors. Compare experience, timelines and customer reviews to choose the right team.</p>

    <div class="cta">
      <a class="btn btn-primary" href="/get-quotes.html">Get Free Quotes</a>
    </div>
  </main>

  <footer class="container">
    <p>Serving homeowners across England, Scotland & Wales</p>
  </footer>
</body>
</html>
'@

# Kitchen Renovation
Write-File "$servicesDir\kitchen-renovation.html" @'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Kitchen Renovation | TradeMatch</title>
  <meta name="description" content="Kitchen renovation specialists: cabinets, worktops, plumbing and electrics. Get free quotes from trusted tradespeople in the UK." />
  <link rel="canonical" href="https://www.tradematch.uk/services/kitchen-renovation" />
  <link rel="icon" href="/favicon.ico" />
</head>
<body>
  <header class="container">
    <a class="logo" href="/">TradeMatch</a>
  </header>

  <main class="container content-block">
    <h1>Kitchen Renovation</h1>

    <p>Kitchen renovations range from cosmetic upgrades to full strip-outs and refits. TradeMatch connects homeowners with qualified kitchen fitters, joiners, plumbers and electricians to deliver coordinated projects from design to installation.</p>

    <h2>Planning your renovation</h2>
    <p>Consider your desired layout, appliances, worktop materials and finishings. Provide measurements and photos when posting your job to get accurate quotes.</p>

    <h2>Working with specialists</h2>
    <p>Many projects require coordination between trades — carpentry, plumbing, tiling and electrics. Our platform surfaces professionals who can manage or coordinate the full project.</p>

    <div class="cta">
      <a class="btn btn-primary" href="/get-quotes.html">Get Free Quotes</a>
    </div>
  </main>

  <footer class="container">
    <p>Serving homeowners across England, Scotland & Wales</p>
  </footer>
</body>
</html>
'@

# Bathroom Fitting
Write-File "$servicesDir\bathroom-fitting.html" @'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Bathroom Fitting | TradeMatch</title>
  <meta name="description" content="Bathroom fitting experts for showers, wet rooms, tiling and plumbing. Get free quotes from trusted installers across the UK." />
  <link rel="canonical" href="https://www.tradematch.uk/services/bathroom-fitting" />
  <link rel="icon" href="/favicon.ico" />
</head>
<body>
  <header class="container">
    <a class="logo" href="/">TradeMatch</a>
  </header>

  <main class="container content-block">
    <h1>Bathroom Fitting</h1>

    <p>Bathroom fitting projects vary from refitting a suite to fully remodeling a bathroom or creating a wet room. TradeMatch helps you find local installers who specialise in tiling, waterproofing, plumbing and finishing works.</p>

    <h2>What to include in your job post</h2>
    <p>Provide current bathroom size, desired fixtures, and whether you want a full rework. Uploading photos helps tradespeople estimate materials and labour accurately.</p>

    <div class="cta">
      <a class="btn btn-primary" href="/get-quotes.html">Get Free Quotes</a>
    </div>
  </main>

  <footer class="container">
    <p>Serving homeowners across England, Scotland & Wales</p>
  </footer>
</body>
</html>
'@

# Roof Repairs
Write-File "$servicesDir\roof-repairs.html" @'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Roof Repairs | TradeMatch</title>
  <meta name="description" content="Roof repairs and maintenance: find local roofing contractors for repairs, re-tiling and emergency response across the UK." />
  <link rel="canonical" href="https://www.tradematch.uk/services/roof-repairs" />
  <link rel="icon" href="/favicon.ico" />
</head>
<body>
  <header class="container">
    <a class="logo" href="/">TradeMatch</a>
  </header>

  <main class="container content-block">
    <h1>Roof Repairs</h1>

    <p>From small leaks to full re-roofing, our network includes local roofers who can repair, replace and maintain a variety of roof types. When you post a roof repair job, include photos, leak location and roof age so contractors can provide timely quotes.</p>

    <h2>Emergency repairs</h2>
    <p>For urgent leaks, many local roofers offer emergency call-outs. Use TradeMatch to quickly find nearby professionals and compare availability and pricing.</p>

    <div class="cta">
      <a class="btn btn-primary" href="/get-quotes.html">Get Free Quotes</a>
    </div>
  </main>

  <footer class="container">
    <p>Serving homeowners across England, Scotland & Wales</p>
  </footer>
</body>
</html>
'@

# robots.txt
Write-File (Join-Path $root 'robots.txt') @'
User-agent: *
Allow: /

Sitemap: https://www.tradematch.uk/sitemap.xml
'@

# sitemap.xml
Write-File (Join-Path $root 'sitemap.xml') @'
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://www.tradematch.uk/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://www.tradematch.uk/services/loft-conversions</loc>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://www.tradematch.uk/services/home-extensions</loc>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://www.tradematch.uk/services/kitchen-renovation</loc>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://www.tradematch.uk/services/bathroom-fitting</loc>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://www.tradematch.uk/services/roof-repairs</loc>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>
'@

# favicon.svg
Write-File (Join-Path $root 'frontend\favicon.svg') @'
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
  <rect width="100%" height="100%" rx="10" fill="#ffffff"/>
  <text x="50%" y="52%" font-size="34" font-family="serif" font-weight="700" text-anchor="middle" fill="#1A2332">TM</text>
</svg>
'@

Write-Host "All files created."