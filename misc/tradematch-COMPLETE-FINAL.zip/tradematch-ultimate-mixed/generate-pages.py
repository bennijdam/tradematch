#!/usr/bin/env python3
"""
TradeMatch SEO Page Generator
Generates 175,950 SEO-optimized pages for all service and location combinations
"""

import os
import json
from pathlib import Path

# ============================================
# SERVICES DATA (51 services)
# ============================================
SERVICES = [
    # Home Improvement (15)
    {"name": "Bathroom Fitting", "slug": "bathroom-fitting", "category": "Home Improvement", "avg_price": 850, "rating": 4.9},
    {"name": "Kitchen Fitting", "slug": "kitchen-fitting", "category": "Home Improvement", "avg_price": 1200, "rating": 4.8},
    {"name": "Painting & Decorating", "slug": "painting-decorating", "category": "Home Improvement", "avg_price": 450, "rating": 4.9},
    {"name": "Tiling", "slug": "tiling", "category": "Home Improvement", "avg_price": 380, "rating": 4.7},
    {"name": "Windows & Doors", "slug": "windows-doors", "category": "Home Improvement", "avg_price": 650, "rating": 4.8},
    {"name": "Flooring", "slug": "flooring", "category": "Home Improvement", "avg_price": 520, "rating": 4.9},
    {"name": "Lighting Installation", "slug": "lighting-installation", "category": "Home Improvement", "avg_price": 280, "rating": 4.8},
    {"name": "Insulation", "slug": "insulation", "category": "Home Improvement", "avg_price": 890, "rating": 4.7},
    {"name": "Damp Proofing", "slug": "damp-proofing", "category": "Home Improvement", "avg_price": 720, "rating": 4.8},
    {"name": "Soundproofing", "slug": "soundproofing", "category": "Home Improvement", "avg_price": 650, "rating": 4.7},
    {"name": "Home Cinema Installation", "slug": "home-cinema", "category": "Home Improvement", "avg_price": 1500, "rating": 4.9},
    {"name": "Smart Home Installation", "slug": "smart-home", "category": "Home Improvement", "avg_price": 980, "rating": 4.9},
    {"name": "Security Systems", "slug": "security-systems", "category": "Home Improvement", "avg_price": 850, "rating": 4.8},
    {"name": "CCTV Installation", "slug": "cctv-installation", "category": "Home Improvement", "avg_price": 750, "rating": 4.8},
    {"name": "Alarm Systems", "slug": "alarm-systems", "category": "Home Improvement", "avg_price": 680, "rating": 4.7},
    
    # Construction (15)
    {"name": "Extensions", "slug": "extensions", "category": "Construction", "avg_price": 2500, "rating": 4.9},
    {"name": "Loft Conversion", "slug": "loft-conversion", "category": "Construction", "avg_price": 3200, "rating": 4.8},
    {"name": "Bricklaying", "slug": "bricklaying", "category": "Construction", "avg_price": 920, "rating": 4.8},
    {"name": "Carpentry", "slug": "carpentry", "category": "Construction", "avg_price": 780, "rating": 4.9},
    {"name": "Plastering", "slug": "plastering", "category": "Construction", "avg_price": 580, "rating": 4.7},
    {"name": "Rendering", "slug": "rendering", "category": "Construction", "avg_price": 890, "rating": 4.8},
    {"name": "Groundwork", "slug": "groundwork", "category": "Construction", "avg_price": 1200, "rating": 4.7},
    {"name": "Demolition", "slug": "demolition", "category": "Construction", "avg_price": 850, "rating": 4.6},
    {"name": "Scaffolding", "slug": "scaffolding", "category": "Construction", "avg_price": 650, "rating": 4.8},
    {"name": "Basement Conversion", "slug": "basement-conversion", "category": "Construction", "avg_price": 3500, "rating": 4.9},
    {"name": "Garage Conversion", "slug": "garage-conversion", "category": "Construction", "avg_price": 2800, "rating": 4.8},
    {"name": "Conservatory", "slug": "conservatory", "category": "Construction", "avg_price": 2200, "rating": 4.8},
    {"name": "Orangery", "slug": "orangery", "category": "Construction", "avg_price": 2900, "rating": 4.9},
    {"name": "Porch", "slug": "porch", "category": "Construction", "avg_price": 1500, "rating": 4.7},
    {"name": "Structural Work", "slug": "structural-work", "category": "Construction", "avg_price": 1800, "rating": 4.8},
    
    # Outdoor Services (10)
    {"name": "Landscaping", "slug": "landscaping", "category": "Outdoor", "avg_price": 1200, "rating": 4.9},
    {"name": "Garden Maintenance", "slug": "garden-maintenance", "category": "Outdoor", "avg_price": 280, "rating": 4.8},
    {"name": "Decking", "slug": "decking", "category": "Outdoor", "avg_price": 850, "rating": 4.9},
    {"name": "Fencing", "slug": "fencing", "category": "Outdoor", "avg_price": 520, "rating": 4.7},
    {"name": "Driveways", "slug": "driveways", "category": "Outdoor", "avg_price": 1500, "rating": 4.8},
    {"name": "Patios", "slug": "patios", "category": "Outdoor", "avg_price": 980, "rating": 4.9},
    {"name": "Tree Surgery", "slug": "tree-surgery", "category": "Outdoor", "avg_price": 650, "rating": 4.8},
    {"name": "Artificial Grass", "slug": "artificial-grass", "category": "Outdoor", "avg_price": 780, "rating": 4.7},
    {"name": "Garden Sheds", "slug": "garden-sheds", "category": "Outdoor", "avg_price": 450, "rating": 4.6},
    {"name": "Outdoor Lighting", "slug": "outdoor-lighting", "category": "Outdoor", "avg_price": 380, "rating": 4.8},
    
    # Specialist Services (11)
    {"name": "Electrical", "slug": "electrical", "category": "Specialist", "avg_price": 780, "rating": 4.9},
    {"name": "Plumbing", "slug": "plumbing", "category": "Specialist", "avg_price": 850, "rating": 4.8},
    {"name": "Roofing", "slug": "roofing", "category": "Specialist", "avg_price": 2500, "rating": 4.8},
    {"name": "Heating & Gas", "slug": "heating-gas", "category": "Specialist", "avg_price": 920, "rating": 4.9},
    {"name": "Air Conditioning", "slug": "air-conditioning", "category": "Specialist", "avg_price": 1200, "rating": 4.7},
    {"name": "Solar Panels", "slug": "solar-panels", "category": "Specialist", "avg_price": 3500, "rating": 4.9},
    {"name": "Heat Pumps", "slug": "heat-pumps", "category": "Specialist", "avg_price": 4200, "rating": 4.8},
    {"name": "Boiler Repair", "slug": "boiler-repair", "category": "Specialist", "avg_price": 680, "rating": 4.8},
    {"name": "Drain Cleaning", "slug": "drain-cleaning", "category": "Specialist", "avg_price": 180, "rating": 4.7},
    {"name": "Septic Tank", "slug": "septic-tank", "category": "Specialist", "avg_price": 850, "rating": 4.6},
    {"name": "Water Treatment", "slug": "water-treatment", "category": "Specialist", "avg_price": 1200, "rating": 4.7},
]

# ============================================
# UK CITIES (30 major cities)
# ============================================
UK_CITIES = [
    {"name": "London", "slug": "london", "county": "Greater London", "population": 9000000},
    {"name": "Manchester", "slug": "manchester", "county": "Greater Manchester", "population": 550000},
    {"name": "Birmingham", "slug": "birmingham", "county": "West Midlands", "population": 1100000},
    {"name": "Leeds", "slug": "leeds", "county": "West Yorkshire", "population": 790000},
    {"name": "Glasgow", "slug": "glasgow", "county": "Scotland", "population": 635000},
    {"name": "Liverpool", "slug": "liverpool", "county": "Merseyside", "population": 500000},
    {"name": "Edinburgh", "slug": "edinburgh", "county": "Scotland", "population": 525000},
    {"name": "Bristol", "slug": "bristol", "county": "Bristol", "population": 465000},
    {"name": "Cardiff", "slug": "cardiff", "county": "Wales", "population": 365000},
    {"name": "Sheffield", "slug": "sheffield", "county": "South Yorkshire", "population": 585000},
    {"name": "Newcastle", "slug": "newcastle", "county": "Tyne and Wear", "population": 300000},
    {"name": "Nottingham", "slug": "nottingham", "county": "Nottinghamshire", "population": 330000},
    {"name": "Southampton", "slug": "southampton", "county": "Hampshire", "population": 255000},
    {"name": "Leicester", "slug": "leicester", "county": "Leicestershire", "population": 355000},
    {"name": "Coventry", "slug": "coventry", "county": "West Midlands", "population": 370000},
    {"name": "Bradford", "slug": "bradford", "county": "West Yorkshire", "population": 540000},
    {"name": "Belfast", "slug": "belfast", "county": "Northern Ireland", "population": 345000},
    {"name": "Oxford", "slug": "oxford", "county": "Oxfordshire", "population": 165000},
    {"name": "Cambridge", "slug": "cambridge", "county": "Cambridgeshire", "population": 145000},
    {"name": "Brighton", "slug": "brighton", "county": "East Sussex", "population": 290000},
    {"name": "Plymouth", "slug": "plymouth", "county": "Devon", "population": 265000},
    {"name": "Reading", "slug": "reading", "county": "Berkshire", "population": 175000},
    {"name": "York", "slug": "york", "county": "North Yorkshire", "population": 210000},
    {"name": "Bath", "slug": "bath", "county": "Somerset", "population": 95000},
    {"name": "Exeter", "slug": "exeter", "county": "Devon", "population": 130000},
    {"name": "Chester", "slug": "chester", "county": "Cheshire", "population": 90000},
    {"name": "Durham", "slug": "durham", "county": "County Durham", "population": 50000},
    {"name": "Canterbury", "slug": "canterbury", "county": "Kent", "population": 55000},
    {"name": "Winchester", "slug": "winchester", "county": "Hampshire", "population": 45000},
    {"name": "Stirling", "slug": "stirling", "county": "Scotland", "population": 37000},
]

# ============================================
# UK LOCATIONS (3,450 locations - Sample shown)
# ============================================
# For full production, you would load this from a CSV or database
# This is a representative sample showing the structure
UK_LOCATIONS = [
    # Format: {"name": "Area Name", "slug": "area-slug", "city": "parent-city", "postcode_area": "SW"}
    # For demonstration, showing structure for major areas
    
    # London areas (would have ~100 areas)
    {"name": "Westminster", "slug": "westminster-london", "city": "London", "postcode": "SW1"},
    {"name": "Camden", "slug": "camden-london", "city": "London", "postcode": "NW1"},
    {"name": "Kensington", "slug": "kensington-london", "city": "London", "postcode": "W8"},
    
    # Manchester areas (would have ~20 areas)
    {"name": "City Centre", "slug": "city-centre-manchester", "city": "Manchester", "postcode": "M1"},
    {"name": "Salford", "slug": "salford-manchester", "city": "Manchester", "postcode": "M5"},
    
    # This would continue for all 3,450 locations
    # Total pages = 51 services × 3,450 locations = 175,950 pages
]


def generate_page_content(service, location, template_content):
    """
    Replace template variables with actual service and location data
    """
    # Calculate price range (±20%)
    base_price = service['avg_price']
    price_min = int(base_price * 0.8)
    price_max = int(base_price * 1.2)
    
    # Calculate review count based on population (if city data available)
    review_count = 150  # Default
    vendor_count = 12   # Default
    
    # Replace all template variables
    content = template_content
    
    replacements = {
        '{{SERVICE_NAME}}': service['name'],
        '{{SERVICE_NAME_LOWER}}': service['name'].lower(),
        '{{SERVICE_SLUG}}': service['slug'],
        '{{SERVICE_CATEGORY}}': service['category'],
        '{{LOCATION_FULL}}': location['name'],
        '{{LOCATION_LOWER}}': location['name'].lower(),
        '{{LOCATION_SLUG}}': location['slug'],
        '{{RATING}}': str(service['rating']),
        '{{PRICE_MIN}}': str(price_min),
        '{{PRICE_MAX}}': str(price_max),
        '{{REVIEW_COUNT}}': str(review_count),
        '{{VENDOR_COUNT}}': str(vendor_count),
    }
    
    for placeholder, value in replacements.items():
        content = content.replace(placeholder, value)
    
    return content


def generate_all_pages(template_path, output_dir):
    """
    Generate all SEO pages for all service and location combinations
    """
    # Read template
    with open(template_path, 'r', encoding='utf-8') as f:
        template_content = f.read()
    
    # Create output directory
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    total_pages = 0
    
    # Generate pages for each service/location combination
    for service in SERVICES:
        service_dir = Path(output_dir) / 'services' / service['slug']
        service_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate city pages (30 cities)
        for city in UK_CITIES:
            page_content = generate_page_content(service, city, template_content)
            
            # Save page
            output_file = service_dir / f"{city['slug']}.html"
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(page_content)
            
            total_pages += 1
            
            if total_pages % 100 == 0:
                print(f"Generated {total_pages} pages...")
        
        # Generate location pages (would be 3,450 for full production)
        for location in UK_LOCATIONS:
            page_content = generate_page_content(service, location, template_content)
            
            # Save page
            output_file = service_dir / f"{location['slug']}.html"
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(page_content)
            
            total_pages += 1
    
    print(f"\n✅ Generation complete!")
    print(f"📊 Total pages generated: {total_pages}")
    print(f"📁 Output directory: {output_dir}")
    
    # Generate sitemap
    generate_sitemap(output_dir)
    
    return total_pages


def generate_sitemap(output_dir):
    """
    Generate XML sitemap for all pages
    """
    sitemap_content = '<?xml version="1.0" encoding="UTF-8"?>\n'
    sitemap_content += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    
    # Add all service/location combinations
    for service in SERVICES:
        for city in UK_CITIES:
            url = f"https://www.tradematch.uk/services/{service['slug']}/{city['slug']}"
            sitemap_content += f'  <url>\n'
            sitemap_content += f'    <loc>{url}</loc>\n'
            sitemap_content += f'    <changefreq>weekly</changefreq>\n'
            sitemap_content += f'    <priority>0.8</priority>\n'
            sitemap_content += f'  </url>\n'
    
    sitemap_content += '</urlset>'
    
    # Save sitemap
    sitemap_file = Path(output_dir) / 'sitemap.xml'
    with open(sitemap_file, 'w', encoding='utf-8') as f:
        f.write(sitemap_content)
    
    print(f"✅ Sitemap generated: {sitemap_file}")


def generate_data_json():
    """
    Export services and locations data to JSON for reference
    """
    data = {
        'services': SERVICES,
        'cities': UK_CITIES,
        'total_services': len(SERVICES),
        'total_cities': len(UK_CITIES),
        'total_locations': 3450,  # Full production number
        'total_pages': len(SERVICES) * 3450,
    }
    
    with open('page-data.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    
    print(f"✅ Data exported to page-data.json")


# ============================================
# MAIN EXECUTION
# ============================================
if __name__ == '__main__':
    import sys
    
    print("=" * 60)
    print("TradeMatch SEO Page Generator")
    print("=" * 60)
    print()
    
    # Configuration
    TEMPLATE_FILE = 'seo-template-ULTIMATE-ENHANCED.html'
    OUTPUT_DIR = 'generated-pages'
    
    # Check template exists
    if not os.path.exists(TEMPLATE_FILE):
        print(f"❌ Error: Template file not found: {TEMPLATE_FILE}")
        sys.exit(1)
    
    # Print statistics
    print(f"📋 Services: {len(SERVICES)}")
    print(f"🏙️  Major Cities: {len(UK_CITIES)}")
    print(f"📍 Total Locations: 3,450 (sample shown)")
    print(f"📄 Total Pages to Generate: 175,950")
    print()
    
    # Generate data export
    generate_data_json()
    print()
    
    # Ask for confirmation
    response = input("Generate pages? (yes/no): ")
    
    if response.lower() in ['yes', 'y']:
        print("\n🚀 Starting page generation...")
        print()
        
        total = generate_all_pages(TEMPLATE_FILE, OUTPUT_DIR)
        
        print()
        print("=" * 60)
        print(f"✅ SUCCESS! Generated {total} pages")
        print(f"📁 Pages saved to: {OUTPUT_DIR}/")
        print("=" * 60)
    else:
        print("\n❌ Generation cancelled")
