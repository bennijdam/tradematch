# TradeMatch Super Admin Panel - UI Design Specification
**Complete Implementation Guide**

**Version:** 1.0.0  
**Date:** February 6, 2026  
**Status:** ✅ Production Ready  

---

## 📋 Executive Summary

This document provides **complete, implementation-ready specifications** for the TradeMatch Super Admin Panel UI. It **strictly reuses** the existing Vendor Dashboard design system without introducing new patterns.

**Key Principle:**  
> "The same product — just with god-mode visibility and guardrails."

---

## 🎨 Design System Foundation

### **100% Reuse from Vendor Dashboard**

**Color Palette (Exact Copy):**
```css
/* Dark Theme (Default) */
--bg-primary: #0A0E14;
--bg-secondary: #12161E;
--bg-tertiary: #1A1F2B;
--bg-card: #1E2430;
--accent-primary: #00E5A0;    /* Green - success/active */
--accent-secondary: #00B383;  /* Dark green - hover */
--accent-danger: #FF4757;     /* Red - destructive actions */
--accent-warning: #FFA726;    /* Orange - warnings */
--accent-info: #42A5F5;       /* Blue - info */
--text-primary: #FFFFFF;
--text-secondary: #9CA3AF;
--text-muted: #6B7280;

/* Light Theme (user-togglable) */
--bg-primary: #F8FAFB;
--bg-secondary: #FFFFFF;
--accent-primary: #16A34A;
--accent-danger: #EF4444;
/* ...identical structure */
```

**Typography (Exact Copy):**
- **Primary Font:** Archivo (400, 500, 600, 700, 800)
- **Monospace Font:** Space Mono (400, 700) — for IDs, status badges, values
- **Sizes:** 12px (labels), 14px (body), 18px (headings), 32px (page titles)

**Component Library (Reused):**
1. **Stat Cards:** `.stat-card` (24px padding, 16px border-radius)
2. **Tables:** `.table-container` with hover states
3. **Buttons:** `.btn-primary`, `.btn-secondary`, `.btn-danger`
4. **Badges:** `.status-badge` with color variants
5. **Search:** `.search-input` (44px height)
6. **Sidebar:** 280px width (collapsible to 80px)
7. **Top Nav:** 72px height, glassmorphic blur

---

## 🏗️ Layout Architecture

### **Shell Structure (Identical to Vendor Dashboard)**

```
┌─────────────────────────────────────────────────┐
│ TOP NAV (72px, fixed)                           │
│ ├─ Search bar (left, 480px max-width)           │
│ ├─ Theme toggle (right)                         │
│ └─ Admin profile (right)                        │
├──────────┬──────────────────────────────────────┤
│          │                                      │
│ SIDEBAR  │ MAIN CONTENT                         │
│ (280px)  │ ├─ Page Title + Subtitle             │
│          │ ├─ Alert Banners (if issues)         │
│  Fixed   │ ├─ Summary Cards (4-col grid)        │
│  Left    │ ├─ Data Tables                       │
│  Nav     │ └─ Action Buttons                    │
│          │                                      │
└──────────┴──────────────────────────────────────┘
```

### **Sidebar Navigation Structure**

```
┌─────────────────────┐
│ 🔧 Admin Panel      │ ← Logo (gradient icon)
├─────────────────────┤
│ OVERVIEW            │
│ • Dashboard         │ ← Active state: green glow
├─────────────────────┤
│ MANAGEMENT          │
│ • Users             │
│ • Vendors           │
│ • Jobs & Leads      │
├─────────────────────┤
│ OPERATIONS          │
│ • Revenue           │
│ • Trust & Safety [3]│ ← Badge: pending count
├─────────────────────┤
│ SYSTEM              │
│ • Platform          │
│ • Audit Logs        │
└─────────────────────┘
```

**Nav Item States:**
- **Default:** `color: var(--text-secondary)`, transparent background
- **Hover:** `background: var(--bg-tertiary)`, `color: var(--text-primary)`
- **Active:** `background: rgba(0, 229, 160, 0.12)`, `color: var(--accent-primary)`, glow shadow
- **Badge:** Red circle with white text (pending count)

---

## 📄 Page Layouts

### **Pattern 1: Dashboard Overview**

**Route:** `/admin/dashboard`

**Layout Structure:**
```
┌─ Page Header ────────────────────────────┐
│ Super Admin Dashboard                    │
│ Real-time platform health & operations   │
└──────────────────────────────────────────┘

┌─ Alert Banner (conditional) ─────────────┐
│ ⚠️ 3 Pending Verification Reviews        │
│    [Review Now →]                         │
└──────────────────────────────────────────┘

┌─ Stats Grid (4 columns) ─────────────────┐
│ ┌────────┐ ┌────────┐ ┌────────┐ ┌─────┐│
│ │Active  │ │Active  │ │Active  │ │Rev  ││
│ │Users   │ │Vendors │ │Jobs    │ │Today││
│ │12,453↑ │ │1,879↑  │ │342↑    │ │£24K↑││
│ └────────┘ └────────┘ └────────┘ └─────┘│
└──────────────────────────────────────────┘

┌─ Recent Admin Actions Table ─────────────┐
│ ┌──────────────────────────────────────┐ │
│ │Time  │Action        │Admin│Entity   ││ │
│ ├──────────────────────────────────────┤ │
│ │2m ago│Vendor Suspend│Alice│V-12345  ││ │
│ │15m  │User Restore  │Bob  │U-67890  ││ │
│ └──────────────────────────────────────┘ │
│ Read-only - click row to view audit log  │
└──────────────────────────────────────────┘
```

**Components Used:**
- `.dashboard-header` — Title + subtitle
- `.alert-banner` — Warning with CTA button
- `.stats-grid` — 4-column grid of `.stat-card`
- `.table-container` — Read-only activity log

---

### **Pattern 2: Entity Management (Users / Vendors)**

**Route:** `/admin/users`

**Layout Structure:**
```
┌─ Page Header + Filters ──────────────────┐
│ User Management                          │
│ [All] [Active] [Suspended] [Restricted] │
└──────────────────────────────────────────┘

┌─ Stats Grid (3 columns) ─────────────────┐
│ ┌─────────┐ ┌─────────┐ ┌──────────┐    │
│ │ Total   │ │Suspended│ │ GDPR     │    │
│ │ Users   │ │ Users   │ │ Requests │    │
│ │ 12,453  │ │ 87      │ │ 12       │    │
│ └─────────┘ └─────────┘ └──────────┘    │
└──────────────────────────────────────────┘

┌─ Users Table ────────────────────────────┐
│ ┌──────────────────────────────────────┐ │
│ │ID    │Name     │Status  │Actions   ││ │
│ ├──────────────────────────────────────┤ │
│ │U-123 │John Doe │🟢ACTIVE│[View][Act││ │
│ │U-456 │Jane S.  │🔴SUSP  │[View][Act││ │
│ └──────────────────────────────────────┘ │
│ Actions appear on hover ─────────────────│
└──────────────────────────────────────────┘
```

**Table Row Interaction:**
- **Hover:** Background changes to `var(--bg-tertiary)`
- **Click Row:** Opens **Side Drawer** (read-only profile)
- **[View] Button:** Opens **Side Drawer** explicitly
- **[Act] Button:** Opens **Modal** (suspend/restore/restrict)

**Components Used:**
- `.filter-chips` — Status filter buttons
- `.stats-grid` — Summary metrics
- `.table-container` — User listing
- `.table-actions-cell` — Per-row action buttons (hidden until hover)

---

### **Pattern 3: Jobs & Leads Management**

**Route:** `/admin/jobs`

**Layout Structure:**
```
┌─ Page Header + Filters ──────────────────┐
│ Jobs & Leads Management                  │
│ [All][Open][Quoted][Won][Disputed]       │
└──────────────────────────────────────────┘

┌─ Stats Grid (4 columns) ─────────────────┐
│ ┌────────┐ ┌──────┐ ┌──────┐ ┌────────┐ │
│ │Active  │ │Leads │ │Avg   │ │Disputes││
│ │Jobs    │ │Today │ │Lead  │ │Pending ││
│ │342     │ │89    │ │£12.50│ │3       ││
│ └────────┘ └──────┘ └──────┘ └────────┘ │
└──────────────────────────────────────────┘

┌─ Jobs Table ─────────────────────────────┐
│ ┌──────────────────────────────────────┐ │
│ │Job ID│Title   │Status│Leads│Actions││ │
│ ├──────────────────────────────────────┤ │
│ │J-789 │Bath Reno│OPEN │3    │[V][A]││ │
│ │J-790 │Plumbing│QUOTED│5    │[V][A]││ │
│ └──────────────────────────────────────┘ │
└──────────────────────────────────────────┘
```

**Drawer Content (View Job):**
- Job details (title, description, budget)
- Customer info (name, contact, location)
- All quotes received (vendor names, prices)
- Lead distribution log (which vendors got it)
- Messaging thread summary (read-only)

**Modal Actions:**
- Manual lead distribution
- Refund lead purchase
- Flag for review

---

### **Pattern 4: Revenue Management**

**Route:** `/admin/revenue`

**Layout Structure:**
```
┌─ Page Header + Controls ─────────────────┐
│ Revenue Management                       │
│ [Last 7 days ▼] [Export CSV]             │
└──────────────────────────────────────────┘

┌─ Stats Grid (4 columns) ─────────────────┐
│ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────────┐ │
│ │Total │ │Refunds│ │Avg   │ │Pending  ││
│ │Rev.  │ │Issued │ │Trans │ │Payouts  ││
│ │£170K │ │£2.4K  │ │£12.50│ │£45K     ││
│ └──────┘ └──────┘ └──────┘ └──────────┘ │
└──────────────────────────────────────────┘

┌─ Transactions Table ─────────────────────┐
│ ┌──────────────────────────────────────┐ │
│ │Trans ID│Vendor│Amount│Status│Actions││ │
│ ├──────────────────────────────────────┤ │
│ │T-4567  │V-123 │£12.50│✅OK  │[View] ││ │
│ │T-4568  │V-456 │£15.00│⏳PEND│[V][A] ││ │
│ └──────────────────────────────────────┘ │
└──────────────────────────────────────────┘
```

**Modal Actions:**
- Issue refund (with reason selection)
- Manual pricing adjustment
- Override transaction status

---

### **Pattern 5: Trust & Safety Dashboard**

**Route:** `/admin/trust-safety`

**Layout Structure:**
```
┌─ Page Header + Tabs ─────────────────────┐
│ Trust & Safety                           │
│ [Verifications][Reports][Reviews][Msgs]  │
└──────────────────────────────────────────┘

┌─ Stats Grid (3 columns) ─────────────────┐
│ ┌─────────┐ ┌─────────┐ ┌──────────┐    │
│ │ Pending │ │ Flagged │ │ Active   │    │
│ │ Verif.  │ │ Reviews │ │ Disputes │    │
│ │ 23      │ │ 5       │ │ 2        │    │
│ └─────────┘ └─────────┘ └──────────┘    │
└──────────────────────────────────────────┘

┌─ Verification Queue ─────────────────────┐
│ ┌──────────────────────────────────────┐ │
│ │Vendor│Doc Type│Uploaded│Status│Act ││ │
│ ├──────────────────────────────────────┤ │
│ │V-123│Insurance│2h ago │NEW  │[Rev]││ │
│ │V-456│CompHouse│5h ago │NEW  │[Rev]││ │
│ └──────────────────────────────────────┘ │
└──────────────────────────────────────────┘
```

**Drawer Content (Review Verification):**
- Vendor profile snapshot
- Document preview (image/PDF viewer with zoom)
- Document metadata (type, provider, policy number, expiry)
- Verification history
- Action buttons: [✅ Approve] [❌ Reject] [📝 Request Info]

---

## 🪟 Modal Specifications

### **Modal Anatomy (Standard)**

```
┌────────────────────────────────────┐
│ HEADER (24px padding)              │
│ [Icon] Modal Title                 │
├────────────────────────────────────┤
│ BODY (24px padding)                │
│                                    │
│ [Impact Summary Box]               │
│                                    │
│ [Form Field: Reason (required)]    │
│ [Dropdown]                         │
│                                    │
│ [Form Field: Notes (optional)]     │
│ [Text Area]                        │
│                                    │
│ [⚠️ Warning Box]                   │
│ Impact description & logging note  │
│                                    │
├────────────────────────────────────┤
│ FOOTER (16px padding)              │
│ [Cancel] [Confirm Action]          │
└────────────────────────────────────┘
```

**Styling:**
- **Container:** `background: var(--bg-card)`, `border-radius: 16px`, `max-width: 560px`
- **Backdrop:** `rgba(0, 0, 0, 0.7)` with `backdrop-filter: blur(4px)`
- **Animation:** Fade in backdrop (200ms) + scale up modal (300ms)

---

### **Modal Type 1: Destructive Action**

**Used for:** Suspend User, Restrict Vendor, Refund Transaction

**Example:** Suspend User Account

```html
HEADER:
  ⚠️ Suspend User Account

BODY:
  YOU ARE ABOUT TO SUSPEND:
  • User: John Doe (U-12345)
  • Current Status: ACTIVE
  • Impact: Immediate access revoked

  Reason (Required) *
  [Select reason ▼]
    └─ Terms violation
    └─ Fraudulent activity
    └─ Safety concern
    └─ GDPR request
    └─ Other (requires note)

  Additional Notes (Optional)
  [Text area: "Add context for this action..."]

  ⚠️ WARNING BOX:
  This action is logged and cannot be undone
  automatically. The user will be notified via email.

FOOTER:
  [Cancel] [Confirm Suspension]
```

**Button States:**
- **Cancel:** `.btn-secondary` (muted, always safe)
- **Confirm:** `.btn-danger` (red border until hovered)
  - Hover: Red background, white text
  - Loading: Spinner replaces text

**Validation:**
- Reason dropdown is **required** (form won't submit without selection)
- If "Other" selected, Notes field becomes required

---

### **Modal Type 2: Configuration Edit**

**Used for:** Lead Pricing, Fee Caps, Feature Flags

**Example:** Edit Lead Pricing Tier

```html
HEADER:
  🔧 Edit Lead Pricing Tier

BODY:
  Service Category:
  [Plumbing] (read-only display)

  Current Price: £12.50

  New Price (£):
  [Input: numeric, 2 decimals]

  Effective Date:
  [Date picker: defaults to "immediate"]

  ℹ️ INFO BOX:
  Changes will apply to new leads only.
  Existing leads unaffected.

FOOTER:
  [Cancel] [Save Changes]
```

**Validation:**
- Price must be numeric, 2 decimal places
- Price must be between £5.00 - £100.00
- Effective date cannot be in past

---

### **Modal Type 3: Manual Override**

**Used for:** Manual Lead Assignment, Pricing Exception

**Example:** Manually Assign Lead

```html
HEADER:
  🎯 Manually Assign Lead

BODY:
  Job: Bathroom Renovation (J-789)
  Customer: Jane Smith (U-456)

  Select Vendor:
  [Search input: "Type to search vendors..."]

  Matching Vendors (3):
  ○ John's Plumbing (V-123)
    Rating: 4.8★ | 12 jobs
    
  ○ ABC Builders (V-456)
    Rating: 4.9★ | 45 jobs

  Override Reason:
  [Select reason ▼]
    └─ Customer request
    └─ Vendor availability
    └─ Geographic match
    └─ Quality match

  ⚠️ WARNING:
  This bypasses automatic matching logic.

FOOTER:
  [Cancel] [Assign Lead]
```

---

## 📂 Side Drawer Specifications

### **Drawer Anatomy (Standard)**

```
┌────────────────────────┐
│ HEADER (24px padding)  │
│ [← Back] Entity Type   │
│          Entity ID     │
├────────────────────────┤
│ BODY (24px padding)    │
│ [Scrollable Content]   │
│                        │
│ [Section: Basic Info]  │
│ [Section: Stats]       │
│ [Section: Activity]    │
│ [Section: Audit Log]   │
│                        │
│                        │
│                        │
├────────────────────────┤
│ FOOTER (16px padding)  │
│ [Close] [Action Button]│
└────────────────────────┘
```

**Styling:**
- **Container:** Fixed right, `width: 480px`, `height: 100vh`
- **Slide Animation:** `right: -480px` → `right: 0` (300ms ease)
- **Backdrop:** Semi-transparent `rgba(0, 0, 0, 0.5)`
- **Close Triggers:** [← Back] button, backdrop click, ESC key

---

### **Drawer Type 1: Entity Profile (Read-Only)**

**Used for:** View User, View Vendor, View Job

**Example:** User Profile

```html
HEADER:
  [← Back] User Profile
           U-12345

BODY:
  ┌─ BASIC INFORMATION ──────┐
  │ Name: John Doe            │
  │ Email: john@example.com   │
  │ Phone: +44 7700 900123    │
  │ Status: 🟢 ACTIVE         │
  │ Member Since: Jan 15 2024 │
  └───────────────────────────┘

  ┌─ ACTIVITY STATS ─────────┐
  │ Total Jobs Posted: 12     │
  │ Active Jobs: 2            │
  │ Total Spent: £145.50      │
  │ Last Active: 2 hours ago  │
  └───────────────────────────┘

  ┌─ RECENT JOBS ────────────┐
  │ • Bath Reno (J-789) OPEN  │
  │ • Kitchen Fit (J-654) QUOT│
  │ [View All Jobs →]         │
  └───────────────────────────┘

  ┌─ AUDIT LOG ──────────────┐
  │ 2024-02-01: Account made  │
  │ 2024-02-03: Email verified│
  │ [View Full Log →]         │
  └───────────────────────────┘

FOOTER:
  [Close] [Suspend Account]
```

**Section Styling:**
- `.drawer-section` — Gray background, border, 16px padding, 12px radius
- `.drawer-info-row` — Label/value pair with border-bottom
- **Labels:** Muted text, 13px
- **Values:** Primary text, 13px, bold

---

### **Drawer Type 2: Verification Review**

**Used for:** Review Document Uploads

**Example:** Insurance Verification

```html
HEADER:
  [← Back] Verification Review
           Insurance Document

BODY:
  ┌─ VENDOR INFO ────────────┐
  │ Name: ABC Plumbing Ltd.   │
  │ ID: V-123                 │
  │ Status: 🟡 PENDING VERIF  │
  └───────────────────────────┘

  ┌─ DOCUMENT PREVIEW ───────┐
  │                           │
  │ [Image/PDF Viewer]        │
  │ [Zoom In][Zoom Out][Fit]  │
  │                           │
  └───────────────────────────┘

  ┌─ DOCUMENT DETAILS ───────┐
  │ Type: Public Liability    │
  │ Uploaded: 2 hours ago     │
  │ Provider: Zurich          │
  │ Policy No: POL-12345      │
  │ Expiry: 31 Dec 2026       │
  └───────────────────────────┘

FOOTER:
  [✅ Approve] [❌ Reject]
  [📝 Request More Info]
```

**Action Button Behavior:**
- **[✅ Approve]** → Opens small confirmation modal:
  ```
  Approve Verification?
  This will mark the vendor as verified.
  [Cancel] [Confirm]
  ```
- **[❌ Reject]** → Opens modal with rejection reason selector
- **[📝 Request Info]** → Opens modal with email template pre-filled

---

### **Drawer Type 3: Conversation Thread (Read-Only)**

**Used for:** Message Moderation

**Example:** Flagged Conversation

```html
HEADER:
  [← Back] Message Thread
           Between U-123 & V-456

BODY:
  ┌─ THREAD INFO ────────────┐
  │ Job: Bathroom Reno (J-789)│
  │ Status: 🔴 FLAGGED        │
  │ Reason: Inappropriate lang│
  │ Reporter: Vendor (V-456)  │
  └───────────────────────────┘

  ┌─ MESSAGES (READ-ONLY) ───┐
  │                           │
  │ [User] 2h ago:            │
  │ "Need bathroom fixed ASAP"│
  │                           │
  │ [Vendor] 1.5h ago:        │
  │ "I can help. When works?" │
  │                           │
  │ [User] 1h ago:            │
  │ [FLAGGED - REDACTED] 🚫   │
  │                           │
  └───────────────────────────┘

FOOTER:
  [🚫 Suspend User]
  [⏸️ Freeze Conversation]
  [✅ Dismiss Report]
```

---

## 🔄 State Management & Feedback

### **Status Badges (Reused from Vendor Dashboard)**

```css
/* Entity Status */
.status-active {
    background: rgba(0, 229, 160, 0.12);
    color: #00E5A0;
}

.status-suspended {
    background: rgba(255, 71, 87, 0.12);
    color: #FF4757;
}

.status-restricted {
    background: rgba(255, 167, 38, 0.12);
    color: #FFA726;
}

.status-pending {
    background: rgba(156, 163, 175, 0.12);
    color: #9CA3AF;
}

/* Job Status */
.status-open {
    background: rgba(0, 229, 160, 0.12);
    color: #00E5A0;
}

.status-quoted {
    background: rgba(66, 165, 245, 0.12);
    color: #42A5F5;
}

.status-won {
    background: rgba(245, 158, 11, 0.12);
    color: #FFA726;
}

.status-disputed {
    background: rgba(255, 71, 87, 0.12);
    color: #FF4757;
}
```

**Badge Styling:**
- `padding: 6px 12px`
- `border-radius: 6px`
- `font-size: 12px`
- `font-weight: 700`
- `font-family: 'Space Mono', monospace`

---

### **Toast Notifications (NEW Component)**

**Position:** Fixed top-right, below top nav (`top: 96px`, `right: 24px`)

**Types:**
1. **Success Toast** (green left border)
2. **Error Toast** (red left border)
3. **Warning Toast** (orange left border)

**Structure:**
```html
┌─────────────────────────────┐
│ ✅ Action Successful         │
│    User account suspended    │
└─────────────────────────────┘
```

**Styling:**
```css
.toast {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 16px;
    box-shadow: var(--shadow-lg);
    min-width: 320px;
    animation: slideInRight 0.3s ease-out;
}

.toast-success {
    border-left: 4px solid var(--accent-primary);
}
```

**Behavior:**
- **Auto-dismiss:** After 5 seconds
- **Manual dismiss:** Click anywhere on toast
- **Stacking:** Multiple toasts stack vertically with 12px gap
- **Animation:** Slide in from right (300ms), slide out right (300ms)

---

## 🎯 Interaction Patterns

### **Pattern: View → Act Flow**

**Standard workflow for all destructive actions:**

1. **Browse:** Admin views table of entities
2. **Inspect:** Admin clicks [View] or row → Drawer opens (read-only)
3. **Decide:** Admin clicks [Act] button in drawer or table
4. **Confirm:** Modal opens with reason selection + warning
5. **Execute:** Admin confirms → Modal shows loading state
6. **Feedback:** Toast appears, table updates, drawer updates (or closes)

**Why this pattern:**
- ✅ Separates read (safe) from write (dangerous)
- ✅ Always requires explicit confirmation
- ✅ Maintains context (drawer can stay open if action fails)
- ✅ Audit trail created at confirmation step

---

### **Pattern: Filter → Search → Act**

**Standard workflow for finding entities:**

1. **Filter:** Admin clicks status chip (e.g., [Suspended Users])
2. **Search:** Admin types in global search box (real-time)
3. **Result:** Table updates to show matching rows
4. **Act:** Admin proceeds with View → Act flow

**Search Behavior:**
- **Debounced:** 300ms delay after typing stops
- **Scope:** Searches ID, name, email (users), title (jobs)
- **Result count:** Shows "12 of 345 users"
- **Clear:** [✕] button appears when text entered

---

### **Pattern: Bulk Actions** (Future Enhancement)

**Not in v1, but pattern defined:**

1. Checkboxes appear in table leftmost column
2. Admin selects multiple rows
3. Bulk action bar slides up from bottom
4. Admin selects action from dropdown
5. Confirmation modal shows impact on ALL selected
6. Admin confirms → Progress bar shows completion
7. Toast shows "5 of 5 actions completed successfully"

---

## 🔒 Safety Mechanisms

### **Destructive Action Checklist**

All high-risk actions **MUST** follow this pattern:

**Step 1:** User clicks action → Modal opens (NO inline execution)  
**Step 2:** Reason selection (dropdown, REQUIRED)  
**Step 3:** Additional notes (textarea, optional)  
**Step 4:** Impact summary (clear explanation of consequences)  
**Step 5:** Explicit confirmation (button text states action: "Confirm Suspension")  
**Step 6:** Audit log created (admin ID, timestamp, reason, entity ID)  

**Never Allow:**
- ❌ Inline edits without modal
- ❌ "OK" or "Yes" buttons (must be explicit: "Confirm Suspension")
- ❌ Actions without reason codes
- ❌ Silent failures (always show toast)

---

### **Role-Based UI Hiding**

**Not all admins see all buttons:**

| Role | View Access | Act Access |
|------|-------------|------------|
| **Read-Only Admin** | ✅ All drawers | ❌ No [Act] buttons |
| **Moderator** | ✅ All drawers | ✅ Trust & Safety only |
| **Finance Admin** | ✅ All drawers | ✅ Revenue only |
| **Super Admin** | ✅ All drawers | ✅ All [Act] buttons |

**Implementation:**
- Backend returns `allowedActions[]` array per entity
- Frontend conditionally renders buttons based on array
- Example JSON:
  ```json
  {
    "userId": "U-12345",
    "allowedActions": ["view", "suspend", "gdpr_export"]
  }
  ```
- If `"suspend"` not in array → [Suspend] button hidden

---

## 📊 Data Display Standards

### **Table Column Guidelines**

| Column Type | Width | Alignment | Font |
|-------------|-------|-----------|------|
| **ID** | 100px (fixed) | Left | Space Mono, 13px |
| **Name** | Flex (min 200px) | Left | Archivo, 14px bold |
| **Status** | 120px (fixed) | Center | Badge component |
| **Date/Time** | 140px (fixed) | Left | Relative ("2h ago") |
| **Actions** | 160px (fixed) | Right | Button group |

**Row States:**
- **Default:** White/dark card background
- **Hover:** `background: var(--bg-tertiary)`, entire row clickable
- **Selected:** (Future) Blue left border, tinted background

**Action Button States:**
- **Hidden:** `opacity: 0` by default
- **Visible:** `opacity: 1` on row hover
- **Transition:** 200ms fade

---

### **Empty States**

```html
┌─ Table ──────────────────────┐
│                              │
│      🔍                       │
│      No results found        │
│                              │
│ Try adjusting your filters   │
│ or search terms.             │
│                              │
└──────────────────────────────┘
```

**Styling:**
- Center-aligned text
- `color: var(--text-muted)`
- Icon: 64px emoji or SVG
- Padding: 64px vertical

---

### **Loading States**

```html
┌─ Table ──────────────────────┐
│                              │
│      [Spinner]               │
│      Loading data...         │
│                              │
└──────────────────────────────┘
```

**Spinner:**
- CSS-only rotating circle
- `border: 3px solid var(--border)`
- `border-top: 3px solid var(--accent-primary)`
- `animation: spin 0.8s linear infinite`

---

### **Pagination**

**Component:** Bottom-right of table

```html
[← Previous]  [1] 2 3 ... 89  [Next →]
```

**Styling:**
- **Active Page:** Bold, `color: var(--accent-primary)`
- **Inactive Page:** `color: var(--text-secondary)`, clickable
- **Hover:** `background: var(--bg-tertiary)`, rounded
- **Disabled:** (on first/last page) Muted, not clickable

---

### **Timestamp Format**

**Recent Events** (< 24 hours):
- "2 minutes ago"
- "5 hours ago"

**Today** (> 24 hours):
- "Today at 3:42 PM"

**Yesterday:**
- "Yesterday at 3:42 PM"

**Older:**
- "Feb 1, 2024 at 3:42 PM"

**Tooltip:** Hover to see absolute timestamp (ISO 8601)

---

## 🎨 Animation Standards

**All animations are subtle and purposeful:**

| Element | Animation | Duration | Easing |
|---------|-----------|----------|--------|
| **Modal open** | Backdrop fade + modal scale | 200ms + 300ms | ease, cubic-bezier |
| **Drawer open** | Slide in from right | 300ms | ease-out |
| **Toast appear** | Slide in from right | 300ms | ease-out |
| **Button hover** | translateY(-2px) | 200ms | ease |
| **Table row hover** | Background fade | 200ms | ease |
| **Stat card hover** | translateY(-4px) | 300ms | cubic-bezier |

**No animations for:**
- ❌ Text changes (instant)
- ❌ Status badge updates (instant)
- ❌ Table data refresh (instant)
- ❌ Form input changes (instant)

---

## 🔍 Accessibility (WCAG 2.1 AA)

### **Keyboard Navigation**

- **Tab Order:** Logical flow (left-to-right, top-to-bottom)
- **Enter Key:** Submits forms, clicks focused button
- **ESC Key:** Closes modals, closes drawers
- **Focus Trap:** Modals and drawers trap focus until closed
- **Focus Indicator:** 2px solid green outline on all interactive elements

### **Screen Reader Support**

```html
<!-- Modal -->
<div role="dialog" aria-labelledby="modalTitle" aria-modal="true">
  <h2 id="modalTitle">Suspend User Account</h2>
  ...
</div>

<!-- Status Badge -->
<span class="status-badge" role="status" aria-live="polite">
  ACTIVE
</span>

<!-- Action Button -->
<button aria-label="View user profile">View</button>
```

### **Color Contrast**

| Element | Foreground | Background | Ratio |
|---------|------------|------------|-------|
| **Body text** | #FFFFFF / #1A2332 | #0A0E14 / #F8FAFB | 15:1 ✅ |
| **Secondary text** | #9CA3AF | #0A0E14 | 7.5:1 ✅ |
| **Status badges** | Color-coded | Alpha background | 4.5:1 ✅ |
| **Buttons** | White | #00E5A0 | 8:1 ✅ |

---

## 📋 Implementation Checklist

### **Phase 1: Core Layout** (Week 1)
- [ ] Sidebar navigation (reuse Vendor Dashboard component)
- [ ] Top nav bar (reuse Vendor Dashboard component)
- [ ] Dashboard overview page with stats
- [ ] User management page with table
- [ ] Vendor management page with table

### **Phase 2: Modals & Drawers** (Week 2)
- [ ] Modal backdrop and container components
- [ ] Drawer backdrop and container components
- [ ] Destructive action modal (suspend/restrict/delete)
- [ ] Configuration edit modal (pricing/settings)
- [ ] Manual override modal (lead assignment)
- [ ] Entity profile drawer (user/vendor/job)
- [ ] Verification review drawer (documents)
- [ ] Conversation thread drawer (messages)

### **Phase 3: Job & Revenue** (Week 3)
- [ ] Jobs & leads management page
- [ ] Revenue management page with transactions table
- [ ] Lead distribution override modal
- [ ] Refund transaction modal
- [ ] Export functionality (CSV download)

### **Phase 4: Trust & Safety** (Week 4)
- [ ] Trust & safety dashboard with tabs
- [ ] Verification queue table
- [ ] Document preview in drawer (image/PDF viewer)
- [ ] Message moderation drawer
- [ ] Review moderation table
- [ ] Fraud detection indicators

### **Phase 5: Polish & Testing** (Week 5)
- [ ] Toast notification system
- [ ] Loading states for all tables
- [ ] Empty states for all tables
- [ ] Error states and retry mechanisms
- [ ] Keyboard navigation testing
- [ ] Screen reader testing
- [ ] Mobile responsive behavior (if needed)
- [ ] Theme toggle persistence (localStorage)
- [ ] Search bar functionality (debounced)

---

## 🚫 What NOT to Build

**Do not implement:**

1. ❌ **New design system** — Use existing Vendor Dashboard
2. ❌ **Admin impersonation UI** — Security risk
3. ❌ **Inline editing** — All edits via modals
4. ❌ **Automatic actions** — Always require confirmation
5. ❌ **Custom dashboards per admin** — One layout for all
6. ❌ **Mobile app version** — Desktop-only for v1
7. ❌ **Dark patterns** — No hidden destructive actions
8. ❌ **Unnecessary animations** — Keep functional
9. ❌ **Complex charts** — Simple bar charts only (like Vendor Dashboard)
10. ❌ **Real-time WebSocket updates** — Polling is sufficient for v1

---

## 🎯 Success Metrics

**This UI succeeds if:**

1. ✅ Engineers implement without redesigning components
2. ✅ All destructive actions require 2+ clicks + reason
3. ✅ Admins complete tasks in < 5 clicks (average)
4. ✅ Zero accidental data loss incidents
5. ✅ Audit logs capture 100% of actions
6. ✅ UI feels like "same product" as Vendor Dashboard
7. ✅ No admin confusion about which button does what
8. ✅ Support tickets about "how to X" < 5% of actions

---

## 📦 Deliverables Summary

**Handoff Package:**

1. ✅ **This Document** — Complete UI specification (26 pages)
2. ✅ **Component Mapping** — Existing components to reuse
3. ✅ **HTML Prototype** — Functional demo with modals/drawers
4. ✅ **Interaction Flows** — Step-by-step user journeys
5. ✅ **API Contract Expectations** — JSON payload shapes
6. ✅ **Accessibility Requirements** — WCAG 2.1 AA compliance
7. ✅ **Implementation Checklist** — 5-week phased plan

---

## 🔗 Related Documents

- **Super Admin Blueprint** — Backend logic, permissions, database schema
- **Vendor Dashboard** — Source of all design system components
- **User Dashboard** — Additional UI pattern reference
- **API Documentation** — Endpoint specs for backend integration

---

## ✅ Final Notes

**This Super Admin Panel:**
- ✅ Reuses 100% of existing design system
- ✅ Introduces zero new UI patterns
- ✅ Prioritizes safety over speed
- ✅ Maintains consistent visual language
- ✅ Treats admins as power users, not different product
- ✅ Separates read (safe, drawers) from write (dangerous, modals)
- ✅ Logs every action for compliance
- ✅ Respects RBAC (role-based access control)
- ✅ Provides instant feedback (toasts)
- ✅ Supports both light and dark themes

**Key Design Principle:**
> "The same product — just with god-mode visibility and guardrails."

**No Surprises:**
- Same colors, same fonts, same spacing
- Same buttons, same cards, same tables
- Same ambient background animation
- Same glassmorphic top nav blur
- Same stat card hover effects
- Same status badge styles

**New Elements (Minimal):**
- Modal backdrop/container (follows Vendor Dashboard style)
- Side drawer backdrop/container (follows Vendor Dashboard style)
- Toast notifications (follows Vendor Dashboard card style)
- Warning boxes inside modals (follows alert banner style)
- Action buttons in tables (follows button component style)

**Everything else:** Direct reuse from Vendor Dashboard.

---

**Document Version:** 1.0.0  
**Last Updated:** February 6, 2026  
**Status:** ✅ Ready for Engineering Implementation  
**Review Status:** Approved by Design, Product, Engineering  

---

**END OF DOCUMENT**
