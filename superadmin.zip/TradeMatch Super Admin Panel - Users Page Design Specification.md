# **TradeMatch Super Admin Panel \- Users Page Design Specification**

**Version:** 1.0.0  
 **Page:** `/admin/users`  
 **Status:** ✅ Implementation-Ready  
 **Design System:** TradeMatch Vendor Dashboard (100% Reuse)

---

## **📋 Page Purpose**

The **Users Page** is the primary interface for Super Admins to:

* ✅ **Observe** user accounts and activity patterns  
* ✅ **Assess** risk, behavior, and lifecycle states  
* ✅ **Intervene** safely through gated, auditable actions  
* ✅ **Execute** GDPR compliance tools (export, anonymize, delete)  
* ✅ **Investigate** disputes, reviews, and messaging metadata

**Critical Principle:**

Admins view and act ON users, never AS users. No impersonation.

---

## **🏗️ Layout Structure**

### **Shell (Unchanged from Existing Dashboards)**

┌─────────────────────────────────────────────────────┐  
│ TOP NAV BAR (72px, fixed)                           │  
│ ├─ Search: "Search users, IDs, emails..."           │  
│ ├─ Theme Toggle                                     │  
│ └─ Admin Profile                                    │  
├──────────┬──────────────────────────────────────────┤  
│          │                                          │  
│ SIDEBAR  │ MAIN CONTENT AREA                        │  
│ (280px)  │                                          │  
│          │ \[Users Page Content Below\]               │  
│ Active:  │                                          │  
│ → Users  │                                          │  
│          │                                          │  
└──────────┴──────────────────────────────────────────┘

**Sidebar State:**

* **Active Item:** `Users` (highlighted with green glow)  
* **Badge:** Shows count of restricted/suspended users if \> 0  
* **No Changes:** Use existing sidebar component exactly

---

## **📄 Page Content Structure**

### **1\. Page Header**

┌─ Page Header ────────────────────────────────────────┐  
│ Users                                                │  
│ View and manage customer accounts across platform   │  
│                                                      │  
│ \[Optional System Health Indicator\]                  │  
│ • Platform Status: 🟢 Operational                   │  
│ • User System Health: 🟢 Healthy                    │  
└──────────────────────────────────────────────────────┘

**Component:** `.dashboard-header` (reused from Vendor Dashboard)

**Styling:**

* **Title:** 32px, font-weight 800, gradient text  
* **Subtitle:** 16px, secondary text color  
* **Health Indicator:** Optional inline status badges (read-only)

---

### **2\. Summary Cards (Read-Only Metrics)**

┌─ Summary Cards (5-column grid) ──────────────────────┐  
│ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌─────────┐ │  
│ │ Total    │ │ Active   │ │Restricted│ │Suspended│ │  
│ │ Users    │ │ Users    │ │ Users    │ │ Users   │ │  
│ │ 12,453   │ │ 12,279   │ │ 87       │ │ 87      │ │  
│ │          │ │ 98.6%    │ │ 0.7%     │ │ 0.7%    │ │  
│ └──────────┘ └──────────┘ └──────────┘ └─────────┘ │  
│                                                      │  
│ ┌──────────┐                                        │  
│ │ Open     │                                        │  
│ │ Disputes │                                        │  
│ │ 23       │                                        │  
│ │ 0.2%     │                                        │  
│ └──────────┘                                        │  
└──────────────────────────────────────────────────────┘

**Component:** `.stats-grid` with `.stat-card` (reused exactly)

**Cards Content:**

**Card 1: Total Users**

* Icon: 👥 (users icon)  
* Value: `12,453` (Space Mono, 36px)  
* Subtext: Total registered accounts  
* Trend: No trend indicator (static count)

**Card 2: Active Users**

* Icon: 🟢 (active indicator)  
* Value: `12,279`  
* Subtext: `98.6%` of total  
* Trend: `↑ 12%` (vs last month) \- green

**Card 3: Restricted Users**

* Icon: ⚠️ (warning icon)  
* Value: `87`  
* Subtext: `0.7%` of total  
* Trend: None (or `↓ 3%` if improved)  
* Color: Orange accent

**Card 4: Suspended Users**

* Icon: 🔴 (suspended indicator)  
* Value: `87`  
* Subtext: `0.7%` of total  
* Trend: None  
* Color: Red accent

**Card 5: Open Disputes**

* Icon: ⚖️ (disputes icon)  
* Value: `23`  
* Subtext: `0.2%` of users  
* Trend: None  
* Color: Info blue

**Rules:**

* ✅ **Read-only** \- No clickable actions  
* ✅ **Hover effect** \- Same as Vendor Dashboard (lift \+ border highlight)  
* ✅ **Responsive** \- Collapses to 2-column on tablet, 1-column on mobile

---

### **3\. Filter & Search Controls**

┌─ Controls Bar ───────────────────────────────────────┐  
│ \[Search: "Search by name, email, ID..."\]             │  
│                                                      │  
│ Filters:                                             │  
│ \[All Users\] \[Active\] \[Restricted\] \[Suspended\]       │  
│ \[With Disputes\] \[High Risk\] \[Recent Activity\]       │  
│                                                      │  
│ Sort: \[Most Recent ▼\]                                │  
└──────────────────────────────────────────────────────┘

**Components:**

* **Search Box:** `.search-input` (reused from top nav style)  
  * 480px max-width  
  * Icon: 🔍 left-aligned  
  * Placeholder: "Search by name, email, ID..."  
  * Real-time filter (debounced 300ms)  
* **Filter Chips:** `.filter-chip` (reused from Vendor Dashboard)  
  * Default: Transparent with border  
  * Active: Green background (`rgba(0, 229, 160, 0.12)`)  
  * Hover: Border highlight  
* **Sort Dropdown:** `.form-select`  
  * Options: Most Recent, Oldest, Name A-Z, Most Jobs, Most Disputed

**Behavior:**

* **Search:** Filters table in real-time  
* **Filter Chips:** Single-select OR multi-select (depending on backend)  
* **Sort:** Reorders table immediately

---

### **4\. Users Table (Primary Data View)**

┌─ Users Table ────────────────────────────────────────────────────────────────┐  
│ Showing 87 of 12,453 users                                   \[Export CSV ▼\] │  
├──────────────────────────────────────────────────────────────────────────────┤  
│ USER ID │ NAME        │ EMAIL           │ STATUS      │ JOBS │ DISP │ LAST  │ ACTIONS │  
├──────────────────────────────────────────────────────────────────────────────┤  
│ U-12345 │ John Doe    │ john@email.com  │ 🟢 ACTIVE   │ 12   │ 0    │ 2h ago│ \[👁\]\[⚙\] │  
│ U-12346 │ Jane Smith  │ jane@email.com  │ 🔴 SUSPENDED│ 8    │ 2    │ 5d ago│ \[👁\]\[⚙\] │  
│ U-12347 │ Bob Wilson  │ bob@email.com   │ ⚠️ RESTRICT │ 3    │ 0    │ 1d ago│ \[👁\]\[⚙\] │  
│ U-12348 │ Alice Chen  │ alice@email.com │ 🟢 ACTIVE   │ 45   │ 1    │ 10m   │ \[👁\]\[⚙\] │  
│ U-12349 │ Tom Brown   │ tom@email.com   │ 🟢 ACTIVE   │ 2    │ 0    │ 3h ago│ \[👁\]\[⚙\] │  
├──────────────────────────────────────────────────────────────────────────────┤  
│ \[← Previous\]  \[1\] 2 3 ... 498  \[Next →\]                                     │  
└──────────────────────────────────────────────────────────────────────────────┘

**Component:** `.table-container` (reused exactly from Vendor Dashboard)

**Column Specifications:**

| Column | Width | Content | Font |
| ----- | ----- | ----- | ----- |
| **User ID** | 100px | `U-12345` | Space Mono, 13px, muted |
| **Name** | Flex (200px min) | Full name | Archivo, 14px, bold |
| **Email** | Flex (180px min) | Email address | Archivo, 14px, secondary |
| **Status** | 120px | Badge component | Status badge |
| **Jobs** | 60px | Total count | Space Mono, 14px |
| **Disp** | 60px | Dispute count | Space Mono, 14px |
| **Last** | 100px | Relative time | Secondary, 13px |
| **Actions** | 100px | Icon buttons | Right-aligned |

**Status Badge Variants:**

css  
🟢 ACTIVE    → .status-active   (green)  
🔴 SUSPENDED → .status-suspended (red)  
⚠️ RESTRICT  → .status-restricted (orange)  
⏸️ PENDING   → .status-pending   (gray)  
\`\`\`

\*\*Action Buttons (Per Row):\*\*

\*\*\[👁\] View Button\*\*  
\- Icon: Eye icon  
\- Tooltip: "View user profile"  
\- Action: Opens \*\*User Profile Drawer\*\* (read-only)  
\- Style: \`.btn-small .btn-view\` (blue accent on hover)

\*\*\[⚙\] Actions Menu Button\*\*  
\- Icon: Settings/gear icon  
\- Tooltip: "Account actions"  
\- Action: Opens \*\*Account Actions Modal\*\*  
\- Style: \`.btn-small .btn-act\` (secondary, hover highlights)

\*\*Row Interaction:\*\*  
\- \*\*Hover:\*\* Background changes to \`var(\--bg-tertiary)\`  
\- \*\*Click Row:\*\* Opens \*\*User Profile Drawer\*\* (same as View button)  
\- \*\*Action Buttons:\*\* Visible on hover (or always visible on mobile)

\*\*Table Features:\*\*  
\- ✅ \*\*Search:\*\* Real-time filter via search box  
\- ✅ \*\*Sort:\*\* Click column headers (ID, Name, Status, Jobs, etc.)  
\- ✅ \*\*Pagination:\*\* 25 users per page (configurable)  
\- ✅ \*\*Export:\*\* CSV download button (top-right of table header)  
\- ✅ \*\*Empty State:\*\* "No users match your filters" with reset button  
\- ✅ \*\*Loading State:\*\* Spinner with "Loading users..." text

\---

\#\# 🪟 Drawer: User Profile (Read-Only)

\#\#\# \*\*Trigger:\*\*  
\- Click \*\*\[👁\] View\*\* button in table  
\- Click anywhere on table row  
\- Click \*\*View Profile\*\* link in modal confirmations

\#\#\# \*\*Layout:\*\*  
\`\`\`  
┌─ User Profile Drawer (480px wide) ──────────────────┐  
│ \[← Back\]  User Profile                              │  
│           U-12345                                    │  
├──────────────────────────────────────────────────────┤  
│ \[SCROLLABLE CONTENT AREA\]                            │  
│                                                      │  
│ ┌─ BASIC INFORMATION ──────────────────────────┐    │  
│ │ Name: John Doe                               │    │  
│ │ Email: john@example.com                      │    │  
│ │ Phone: \+44 7700 900123                       │    │  
│ │ Status: 🟢 ACTIVE                            │    │  
│ │ Account Created: Jan 15, 2024                │    │  
│ │ Email Verified: ✅ Yes (Jan 15, 2024)        │    │  
│ │ Phone Verified: ✅ Yes (Jan 16, 2024)        │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ ACCOUNT STATUS & TIMELINE ──────────────────┐    │  
│ │ Current Status: ACTIVE                       │    │  
│ │ Previous Status: N/A                         │    │  
│ │ Last Status Change: N/A                      │    │  
│ │                                              │    │  
│ │ Timeline:                                    │    │  
│ │ • 2024-01-15: Account created                │    │  
│ │ • 2024-01-15: Email verified                 │    │  
│ │ • 2024-01-16: Phone verified                 │    │  
│ │ • 2024-01-20: First job posted               │    │  
│ │ \[View Full Timeline →\]                       │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ ACTIVITY STATISTICS ─────────────────────────┐    │  
│ │ Total Jobs Posted: 12                        │    │  
│ │ Active Jobs: 2                               │    │  
│ │ Completed Jobs: 8                            │    │  
│ │ Cancelled Jobs: 2                            │    │  
│ │                                              │    │  
│ │ Total Quotes Received: 47                    │    │  
│ │ Avg Quotes per Job: 3.9                      │    │  
│ │                                              │    │  
│ │ Total Spent: £1,245.50                       │    │  
│ │ Avg Job Value: £103.79                       │    │  
│ │                                              │    │  
│ │ Last Active: 2 hours ago                     │    │  
│ │ Last Job Posted: Feb 1, 2024                 │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ RECENT JOBS ─────────────────────────────────┐    │  
│ │ • Bathroom Renovation (J-789) \- OPEN         │    │  
│ │   Posted: 2 days ago | 3 quotes              │    │  
│ │                                              │    │  
│ │ • Kitchen Sink Repair (J-654) \- QUOTED       │    │  
│ │   Posted: 5 days ago | 5 quotes              │    │  
│ │                                              │    │  
│ │ \[View All Jobs →\]                            │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ REVIEWS LEFT BY USER ────────────────────────┐    │  
│ │ Total Reviews: 8                             │    │  
│ │ Average Rating Given: 4.6 ★                  │    │  
│ │                                              │    │  
│ │ Recent:                                      │    │  
│ │ • ABC Plumbing \- 5★ (Jan 28, 2024)          │    │  
│ │ • QuickFix Builders \- 4★ (Jan 15, 2024)     │    │  
│ │                                              │    │  
│ │ \[View All Reviews →\]                         │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ DISPUTES & FLAGS ────────────────────────────┐    │  
│ │ Active Disputes: 0                           │    │  
│ │ Resolved Disputes: 0                         │    │  
│ │                                              │    │  
│ │ Risk Flags: None                             │    │  
│ │ Trust Score: 95/100 (Excellent)              │    │  
│ │                                              │    │  
│ │ \[View Dispute History →\]                     │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ MESSAGING METADATA ──────────────────────────┐    │  
│ │ Total Conversations: 15                      │    │  
│ │ Active Threads: 2                            │    │  
│ │ Flagged Messages: 0                          │    │  
│ │ Last Message Sent: 1 hour ago                │    │  
│ │                                              │    │  
│ │ \[View Messages (Read-Only) →\]                │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ┌─ AUDIT LOG (Last 5 Events) ───────────────────┐    │  
│ │ 2024-02-05 14:32: Job posted (J-789)         │    │  
│ │ 2024-02-03 09:15: Quote accepted (J-654)     │    │  
│ │ 2024-02-01 16:45: Review left (V-123)        │    │  
│ │ 2024-01-28 11:20: Job completed (J-612)      │    │  
│ │ 2024-01-25 13:05: Profile updated            │    │  
│ │                                              │    │  
│ │ \[View Full Audit Log →\]                      │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER (16px padding)                                │  
│ \[Close\]  \[GDPR Tools ▼\]  \[Account Actions ▼\]        │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Component:\*\* \`.drawer-container\` (new, following Vendor Dashboard style)

\*\*Drawer Sections:\*\* All use \`.drawer-section\` component  
\- Gray background \`var(\--bg-tertiary)\`  
\- 16px padding  
\- 12px border-radius  
\- 1px border \`var(\--border)\`  
\- 16px margin-bottom

\*\*Section Title:\*\* \`.drawer-section-title\`  
\- 13px, uppercase, bold  
\- Muted color  
\- 0.5px letter-spacing

\*\*Info Rows:\*\* \`.drawer-info-row\`  
\- Label/value pairs  
\- Label: 13px, muted  
\- Value: 13px, primary color, bold  
\- Border-bottom between rows

\*\*Behavior:\*\*  
\- ✅ \*\*Scrollable:\*\* Entire drawer body scrolls independently  
\- ✅ \*\*Close:\*\* \[← Back\] button, backdrop click, ESC key  
\- ✅ \*\*Links:\*\* Internal links (View All Jobs, etc.) open new drawer overlays or navigate  
\- ✅ \*\*Read-Only:\*\* No edit fields, no delete buttons inside drawer  
\- ✅ \*\*Footer Actions:\*\* Dropdown menus open modals (explained below)

\---

\#\# 🔲 Modal: Account Actions

\#\#\# \*\*Trigger:\*\*  
\- Click \*\*\[⚙\] Actions\*\* button in table  
\- Click \*\*\[Account Actions ▼\]\*\* dropdown in User Profile Drawer

\#\#\# \*\*Layout:\*\*  
\`\`\`  
┌─ Account Actions Modal ──────────────────────────────┐  
│ ⚙️ Account Actions                                    │  
│ Select an action for: John Doe (U-12345)             │  
├──────────────────────────────────────────────────────┤  
│ BODY (24px padding)                                  │  
│                                                      │  
│ Select Action:                                       │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Radio\] Restrict Account                     │    │  
│ │         Limit account features temporarily   │    │  
│ │                                              │    │  
│ │ \[Radio\] Suspend Account                      │    │  
│ │         Revoke all access immediately        │    │  
│ │                                              │    │  
│ │ \[Radio\] Restore Account                      │    │  
│ │         Remove restrictions/suspensions      │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ \[Next: Configure Action →\]                           │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\]                                             │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Component:\*\* \`.modal-container\` (560px max-width)

\*\*Action Options (Radio Buttons):\*\*

1. \*\*Restrict Account\*\*  
   \- Icon: ⚠️  
   \- Description: "Limit account features temporarily"  
   \- Next Step: Opens \*\*Restrict Account Modal\*\*

2. \*\*Suspend Account\*\*  
   \- Icon: 🔴  
   \- Description: "Revoke all access immediately"  
   \- Next Step: Opens \*\*Suspend Account Modal\*\*

3. \*\*Restore Account\*\*  
   \- Icon: ✅  
   \- Description: "Remove restrictions/suspensions"  
   \- Next Step: Opens \*\*Restore Account Modal\*\*

\*\*Behavior:\*\*  
\- User selects one option  
\- Clicks \*\*\[Next: Configure Action →\]\*\*  
\- Modal transitions to specific action confirmation modal

\---

\#\# 🔲 Modal: Restrict Account

\#\#\# \*\*Triggered After:\*\* Selecting "Restrict Account" in Account Actions modal

\#\#\# \*\*Layout:\*\*  
\`\`\`  
┌─ Restrict Account Modal ─────────────────────────────┐  
│ ⚠️ Restrict Account                                   │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ YOU ARE ABOUT TO RESTRICT:                           │  
│ • User: John Doe (U-12345)                           │  
│ • Current Status: ACTIVE                             │  
│ • Impact: Limited features, can view but not post    │  
│                                                      │  
│ Restriction Type (Required) \*                        │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select restriction type ▼\]                  │    │  
│ │  └─ Cannot post new jobs                     │    │  
│ │  └─ Cannot message vendors                   │    │  
│ │  └─ Cannot leave reviews                     │    │  
│ │  └─ Cannot accept quotes                     │    │  
│ │  └─ Full restriction (all features)          │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Reason (Required) \*                                  │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select reason ▼\]                            │    │  
│ │  └─ Terms violation                          │    │  
│ │  └─ Suspected fraud                          │    │  
│ │  └─ Payment dispute                          │    │  
│ │  └─ Inappropriate messaging                  │    │  
│ │  └─ Review manipulation                      │    │  
│ │  └─ Other (requires notes)                   │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Duration (Required) \*                                │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select duration ▼\]                          │    │  
│ │  └─ 7 days                                   │    │  
│ │  └─ 14 days                                  │    │  
│ │  └─ 30 days                                  │    │  
│ │  └─ 90 days                                  │    │  
│ │  └─ Indefinite (until manual restoration)    │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Additional Notes (Optional)                          │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Text area\]                                  │    │  
│ │ Add context for audit trail...               │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ⚠️ WARNING BOX:                                      │  
│ This action is logged and the user will receive     │  
│ an email notification. They can appeal via support. │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\] \[Confirm Restriction\]                       │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Validation:\*\*  
\- All required fields must be filled  
\- If "Other" reason selected, notes become required  
\- Confirm button disabled until valid

\*\*Success Flow:\*\*  
1. Admin fills form  
2. Clicks \*\*\[Confirm Restriction\]\*\*  
3. Modal shows loading spinner  
4. On success:  
   \- Modal closes  
   \- Toast appears: "✅ User restricted successfully"  
   \- Table row updates status badge to ⚠️ RESTRICTED  
   \- If drawer open, it updates status section  
5. On error:  
   \- Error message displays in modal  
   \- Admin can retry or cancel

\---

\#\# 🔲 Modal: Suspend Account

\#\#\# \*\*Triggered After:\*\* Selecting "Suspend Account" in Account Actions modal

\#\#\# \*\*Layout:\*\*  
\`\`\`  
┌─ Suspend Account Modal ──────────────────────────────┐  
│ 🔴 Suspend Account                                    │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ YOU ARE ABOUT TO SUSPEND:                            │  
│ • User: John Doe (U-12345)                           │  
│ • Current Status: ACTIVE                             │  
│ • Impact: Immediate access revoked, cannot login     │  
│                                                      │  
│ Reason (Required) \*                                  │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select reason ▼\]                            │    │  
│ │  └─ Severe terms violation                   │    │  
│ │  └─ Fraudulent activity                      │    │  
│ │  └─ Safety concern                           │    │  
│ │  └─ Chargeback/payment fraud                 │    │  
│ │  └─ Repeated policy violations               │    │  
│ │  └─ Legal request                            │    │  
│ │  └─ Other (requires detailed notes)          │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Additional Notes (Required) \*                        │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Text area \- required for suspension\]        │    │  
│ │ Detailed justification for audit trail...    │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Notify User?                                         │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[✓\] Send suspension email                    │    │  
│ │ \[ \] Silent suspension (no email)             │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ 🔴 CRITICAL WARNING:                                 │  
│ Suspension is immediate and cannot be undone         │  
│ automatically. User will lose access to all account  │  
│ features. This action is permanently logged.         │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\] \[Confirm Suspension\]                        │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Validation:\*\*  
\- Reason is required  
\- Notes are required (minimum 20 characters)  
\- Notify checkbox pre-selected (admin must explicitly uncheck for silent)

\*\*Button Styling:\*\*  
\- \*\*\[Confirm Suspension\]:\*\* \`.btn-danger\` (red background on hover)

\*\*Success Flow:\*\*  
1. Admin fills form, clicks \[Confirm Suspension\]  
2. Modal shows loading  
3. On success:  
   \- Modal closes  
   \- Toast: "🔴 User suspended successfully"  
   \- Table updates status to 🔴 SUSPENDED  
   \- Drawer updates if open  
   \- Audit log entry created

\---

\#\# 🔲 Modal: Restore Account

\#\#\# \*\*Triggered After:\*\* Selecting "Restore Account" in Account Actions modal

\#\#\# \*\*Layout:\*\*  
\`\`\`  
┌─ Restore Account Modal ──────────────────────────────┐  
│ ✅ Restore Account                                    │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ YOU ARE ABOUT TO RESTORE:                            │  
│ • User: Jane Smith (U-12346)                         │  
│ • Current Status: SUSPENDED                          │  
│ • Impact: Full account access restored               │  
│                                                      │  
│ Restoration Reason (Required) \*                      │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select reason ▼\]                            │    │  
│ │  └─ Appeal approved                          │    │  
│ │  └─ Suspension error                         │    │  
│ │  └─ Issue resolved                           │    │  
│ │  └─ Restriction period ended                 │    │  
│ │  └─ Payment cleared                          │    │  
│ │  └─ Other (requires notes)                   │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Notes (Optional)                                     │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Text area\]                                  │    │  
│ │ Add context for restoration...               │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ℹ️ INFO:                                             │  
│ User will receive email confirmation and regain      │  
│ full platform access immediately.                    │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\] \[Confirm Restoration\]                       │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Success Flow:\*\*  
1. Admin selects reason, adds optional notes  
2. Clicks \*\*\[Confirm Restoration\]\*\*  
3. On success:  
   \- Toast: "✅ Account restored successfully"  
   \- Table updates status to 🟢 ACTIVE  
   \- Email sent to user

\---

\#\# 🔲 Modal: GDPR Tools

\#\#\# \*\*Trigger:\*\*  
\- Click \*\*\[GDPR Tools ▼\]\*\* dropdown in User Profile Drawer

\#\#\# \*\*Layout:\*\*  
\`\`\`  
┌─ GDPR Tools Modal ───────────────────────────────────┐  
│ 🔐 GDPR Compliance Tools                             │  
│ User: John Doe (U-12345)                             │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ Select GDPR Action:                                  │  
│                                                      │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Radio\] Export User Data                     │    │  
│ │         Generate full data export (JSON/CSV) │    │  
│ │         Impact: Read-only, user notified     │    │  
│ │                                              │    │  
│ │ \[Radio\] Anonymize Account                    │    │  
│ │         Remove PII, keep aggregated data     │    │  
│ │         Impact: Irreversible, user cannot    │    │  
│ │                 restore                      │    │  
│ │                                              │    │  
│ │ \[Radio\] Delete Account Permanently           │    │  
│ │         Remove all data, cannot be undone    │    │  
│ │         Impact: Complete removal from system │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ \[Next: Configure GDPR Action →\]                      │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\]                                             │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Behavior:\*\*  
\- Admin selects one option  
\- Clicks \*\*\[Next\]\*\*  
\- Opens specific GDPR action modal (Export, Anonymize, or Delete)

\---

\#\# 🔲 Modal: Export User Data (GDPR)  
\`\`\`  
┌─ Export User Data Modal ─────────────────────────────┐  
│ 📥 Export User Data                                   │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ USER: John Doe (U-12345)                             │  
│                                                      │  
│ Export Format:                                       │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Radio\] JSON (machine-readable)              │    │  
│ │ \[Radio\] CSV (spreadsheet-friendly)           │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Data Scope:                                          │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[✓\] Profile information                      │    │  
│ │ \[✓\] Job history                              │    │  
│ │ \[✓\] Quote history                            │    │  
│ │ \[✓\] Reviews                                  │    │  
│ │ \[✓\] Messages (metadata only)                 │    │  
│ │ \[✓\] Payment transactions                     │    │  
│ │ \[ \] Admin notes (internal, excluded)         │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Delivery Method:                                     │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Radio\] Download immediately                 │    │  
│ │ \[Radio\] Email to user's registered email     │    │  
│ │ \[Radio\] Email to admin (secure)              │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ ℹ️ NOTE:                                             │  
│ Export is logged. User will be notified if sent to  │  
│ their email. Processing may take a few minutes.      │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\] \[Generate Export\]                           │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Success Flow:\*\*  
1. Admin configures export options  
2. Clicks \*\*\[Generate Export\]\*\*  
3. Backend processes request (may take 30-120 seconds)  
4. On success:  
   \- If "Download immediately": File downloads automatically  
   \- If "Email": Toast confirms "Export sent to \[email\]"  
   \- Modal closes  
   \- Audit log entry created

\---

\#\# 🔲 Modal: Anonymize Account (GDPR)  
\`\`\`  
┌─ Anonymize Account Modal ────────────────────────────┐  
│ 🔐 Anonymize Account                                  │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ YOU ARE ABOUT TO ANONYMIZE:                          │  
│ • User: John Doe (U-12345)                           │  
│ • Current Status: ACTIVE                             │  
│                                                      │  
│ What will be removed:                                │  
│ • Name → "User-12345"                                │  
│ • Email → "anon-12345@tradematch.uk"                 │  
│ • Phone → Deleted                                    │  
│ • Address → Deleted                                  │  
│ • Payment info → Deleted                             │  
│ • Messages → Deleted                                 │  
│                                                      │  
│ What will be retained:                               │  
│ • User ID (anonymized)                               │  
│ • Job counts (aggregated stats only)                 │  
│ • Review counts (no text)                            │  
│                                                      │  
│ Legal Basis (Required) \*                             │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select legal basis ▼\]                       │    │  
│ │  └─ GDPR Right to Erasure request            │    │  
│ │  └─ User consent withdrawn                   │    │  
│ │  └─ Legal requirement                        │    │  
│ │  └─ Data retention policy                    │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Admin Justification (Required) \*                     │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Text area \- minimum 50 characters\]          │    │  
│ │ Detailed legal justification...              │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ 🔴 CRITICAL WARNING:                                 │  
│ This action is IRREVERSIBLE. All personal data will  │  
│ be permanently removed. User cannot restore account. │  
│ This requires Data Protection Officer approval.      │  
│                                                      │  
│ DPO Approval Code (Required) \*                       │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Input: 6\-digit code\]                        │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\] \[Confirm Anonymization\]                     │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Validation:\*\*  
\- Legal basis required  
\- Justification required (min 50 chars)  
\- DPO approval code required (6 digits, backend validated)  
\- Double confirmation (modal shows second confirmation after first submit)

\*\*Button Styling:\*\*  
\- \*\*\[Confirm Anonymization\]:\*\* \`.btn-danger\` with extra warning color

\---

\#\# 🔲 Modal: Delete Account Permanently (GDPR)  
\`\`\`  
┌─ Delete Account Modal ───────────────────────────────┐  
│ 🗑️ Delete Account Permanently                        │  
├──────────────────────────────────────────────────────┤  
│ BODY                                                 │  
│                                                      │  
│ ⚠️ EXTREME CAUTION REQUIRED ⚠️                        │  
│                                                      │  
│ YOU ARE ABOUT TO PERMANENTLY DELETE:                 │  
│ • User: John Doe (U-12345)                           │  
│ • Current Status: ACTIVE                             │  
│                                                      │  
│ What will be deleted:                                │  
│ • Entire user account                                │  
│ • All personal information                           │  
│ • Job history                                        │  
│ • Quote history                                      │  
│ • Reviews (both given and received about user)       │  
│ • Messages                                           │  
│ • Payment records                                    │  
│ • All associated metadata                            │  
│                                                      │  
│ Impact on system:                                    │  
│ • Vendor quote counts may decrease                   │  
│ • Review averages may recalculate                    │  
│ • Historical reports affected                        │  
│                                                      │  
│ Legal Basis (Required) \*                             │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Select legal basis ▼\]                       │    │  
│ │  └─ GDPR Right to Erasure (user request)     │    │  
│ │  └─ Court order / legal requirement          │    │  
│ │  └─ Data Protection Authority directive      │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Legal Documentation (Required) \*                     │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[File upload: PDF, max 10MB\]                 │    │  
│ │ Upload legal justification document          │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Admin Justification (Required) \*                     │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Text area \- minimum 100 characters\]         │    │  
│ │ Comprehensive legal and operational          │    │  
│ │ justification for permanent deletion...      │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ DPO Approval Code (Required) \*                       │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Input: 6\-digit code\]                        │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ Type DELETE to confirm:                              │  
│ ┌──────────────────────────────────────────────┐    │  
│ │ \[Input: must type "DELETE" exactly\]          │    │  
│ └──────────────────────────────────────────────┘    │  
│                                                      │  
│ 🔴 FINAL WARNING:                                    │  
│ This action CANNOT BE UNDONE. All data will be       │  
│ permanently erased from all systems and backups.     │  
│ This is a GDPR-compliant hard delete.                │  
│                                                      │  
├──────────────────────────────────────────────────────┤  
│ FOOTER                                               │  
│ \[Cancel\] \[Permanently Delete Account\]                │  
└──────────────────────────────────────────────────────┘  
\`\`\`

\*\*Validation:\*\*  
\- All fields required  
\- Legal documentation file required  
\- DPO code validated by backend  
\- Must type "DELETE" exactly (case-sensitive)  
\- After submit: Second confirmation modal appears asking "Are you absolutely certain?"

\*\*Button Styling:\*\*  
\- \*\*\[Permanently Delete Account\]:\*\* \`.btn-danger\` with darkest red, disabled until all validations pass

\---

\#\# 🎯 User Flows

\#\#\# \*\*Flow 1: View User Profile\*\*  
\`\`\`  
1. Admin lands on /admin/users page  
2. Sees table of all users  
3. Searches for "John Doe" in search box  
4. Table filters to show matching user  
5. Admin clicks anywhere on table row (or \[👁\] View button)  
6. → User Profile Drawer slides in from right  
7. Admin reviews:  
   \- Basic info  
   \- Account status & timeline  
   \- Activity stats  
   \- Recent jobs  
   \- Reviews  
   \- Disputes  
   \- Messaging metadata  
   \- Audit log  
8. Admin clicks \[← Back\] or presses ESC  
9. → Drawer closes  
10. Admin returns to table  
\`\`\`

\---

\#\#\# \*\*Flow 2: Restrict User Account\*\*  
\`\`\`  
1. Admin views user table  
2. Finds user "John Doe" via search  
3. Clicks \[⚙\] Actions button in user row  
4. → Account Actions Modal opens  
5. Admin selects "Restrict Account" radio button  
6. Clicks \[Next: Configure Action →\]  
7. → Modal transitions to Restrict Account Modal  
8. Admin fills form:  
   \- Restriction Type: "Cannot post new jobs"  
   \- Reason: "Payment dispute"  
   \- Duration: "14 days"  
   \- Notes: "Chargeback pending resolution"  
9. Admin clicks \[Confirm Restriction\]  
10. → Loading spinner appears in button  
11. → Backend processes (2 seconds)  
12. → Modal closes  
13. → Toast appears: "✅ User restricted successfully"  
14. → Table row updates:  
    \- Status badge changes to ⚠️ RESTRICTED  
15. → If drawer was open, status section updates  
16. → Audit log entry created:  
    "2024-02-06 15:45: Account restricted (14 days) by Admin SA-001. Reason: Payment dispute."  
17. → User receives email: "Your account has been temporarily restricted..."  
\`\`\`

\---

\#\#\# \*\*Flow 3: Suspend User Account\*\*  
\`\`\`  
1. Admin navigates to Users page  
2. Applies filter: \[Suspended\] chip to review existing cases  
3. Decides to suspend new user "Jane Smith"  
4. Clicks \[All Users\] chip to reset filter  
5. Searches for "Jane Smith"  
6. Clicks \[👁\] View to review profile first  
7. → User Profile Drawer opens  
8. Admin reviews:  
   \- 5 active jobs  
   \- 2 open disputes  
   \- 3 flagged messages  
9. Admin clicks \[Account Actions ▼\] dropdown in drawer footer  
10. → Account Actions Modal opens  
11. Admin selects "Suspend Account"  
12. Clicks \[Next\]  
13. → Suspend Account Modal opens  
14. Admin fills form:  
    \- Reason: "Repeated policy violations"  
    \- Notes: "User has violated community guidelines 3 times in 2 weeks despite warnings. Latest: inappropriate messaging to vendor."  
    \- Notify User: \[✓\] Checked (default)  
15. Admin clicks \[Confirm Suspension\]  
16. → Button shows loading spinner  
17. → Backend processes suspension  
18. → Modal closes  
19. → Toast: "🔴 User suspended successfully"  
20. → Drawer status updates to 🔴 SUSPENDED  
21. → Table row updates status badge  
22. → User receives suspension email  
23. → User's active jobs marked "Customer Suspended"  
24. → Vendors notified of suspension  
25. → Audit log entry created  
\`\`\`

\---

\#\#\# \*\*Flow 4: Export User Data (GDPR Request)\*\*  
\`\`\`  
1. Support ticket: "User requests all their data per GDPR"  
2. Admin navigates to Users page  
3. Searches for user by email  
4. Clicks \[👁\] View  
5. → User Profile Drawer opens  
6. Admin clicks \[GDPR Tools ▼\] dropdown  
7. → GDPR Tools Modal opens  
8. Admin selects "Export User Data"  
9. Clicks \[Next\]  
10. → Export User Data Modal opens  
11. Admin configures:  
    \- Format: JSON  
    \- Scope: All checkboxes checked  
    \- Delivery: Email to user's registered email  
12. Admin clicks \[Generate Export\]  
13. → Modal shows progress: "Processing export... (30%)"  
14. → Backend generates JSON file (45 seconds)  
15. → Modal updates: "Export complete\! Sending email..."  
16. → Email sent to user with secure download link  
17. → Toast: "✅ Export sent to john@example.com"  
18. → Modal closes  
19. → Audit log: "GDPR data export generated and sent to user"  
20. → Admin can close drawer  
\`\`\`

\---

\#\#\# \*\*Flow 5: Anonymize Account (GDPR Right to Erasure)\*\*  
\`\`\`  
1. User submits GDPR erasure request via support  
2. Support escalates to Super Admin  
3. Admin navigates to Users page  
4. Searches for user  
5. Clicks \[👁\] View  
6. → Drawer opens  
7. Admin reviews account:  
   \- No active jobs  
   \- No open disputes  
   \- No pending quotes  
   → Safe to proceed  
8. Admin clicks \[GDPR Tools ▼\]  
9. Selects "Anonymize Account"  
10. Clicks \[Next\]  
11. → Anonymize Account Modal opens  
12. Admin reads impact summary carefully  
13. Admin fills form:  
    \- Legal Basis: "GDPR Right to Erasure request"  
    \- Justification: "User submitted formal erasure request via email on 2024-02-05. User confirmed via identity verification. No legal retention requirements apply. Account has no active obligations."  
    \- DPO Approval Code: \[Contacts DPO, receives code: "748291"\]  
14. Admin enters code: 748291  
15. Admin clicks \[Confirm Anonymization\]  
16. → Second confirmation modal: "Are you absolutely certain? Type ANONYMIZE to confirm"  
17. Admin types "ANONYMIZE"  
18. Clicks final \[Confirm\]  
19. → Backend processes:  
    \- Name → "User-12345"  
    \- Email → "anon-12345@tradematch.uk"  
    \- Phone → Deleted  
    \- All PII → Removed  
20. → Toast: "✅ Account anonymized successfully"  
21. → Drawer updates to show anonymized data  
22. → Table row shows User-12345, status: ANONYMIZED  
23. → Audit log: "GDPR anonymization completed by Admin SA-001"  
24. → User receives final email: "Your data has been anonymized per your request"  
---

## **📊 Component Specifications Summary**

### **Reused Components (from Vendor Dashboard)**

| Component | Usage | Location |
| ----- | ----- | ----- |
| `.dashboard-header` | Page title \+ subtitle | Top of page |
| `.stats-grid` | Summary metric cards | Below header |
| `.stat-card` | Individual metric card | Inside stats-grid |
| `.search-input` | Global search box | Controls bar |
| `.filter-chip` | Status filter buttons | Controls bar |
| `.form-select` | Dropdown menus | Modals, controls |
| `.table-container` | Main users table | Primary content |
| `.status-badge` | Status indicators | Tables, drawers |
| `.btn-primary` | Confirmation actions | Modal footers |
| `.btn-secondary` | Cancel actions | Modal footers |
| `.btn-small` | Table row actions | Action columns |

### **New Components (Following Vendor Style)**

| Component | Purpose | Styling Reference |
| ----- | ----- | ----- |
| `.drawer-container` | Side panel for profiles | Same card bg, 480px wide |
| `.drawer-section` | Content blocks in drawer | Same as stat-card style |
| `.modal-container` | Action confirmations | Same card bg, 560px max |
| `.btn-danger` | Destructive confirmations | Red variant of btn-primary |
| `.warning-box` | Critical warnings in modals | Same as alert-banner |
| `.toast` | Success/error feedback | Same card bg, top-right |

---

## **✅ Accessibility & Safety Checklist**

### **Keyboard Navigation**

* ✅ Tab through all interactive elements  
* ✅ Enter to submit forms  
* ✅ ESC to close modals/drawers  
* ✅ Arrow keys in dropdowns  
* ✅ Focus indicators visible (2px green outline)

### **Screen Reader Support**

* ✅ All modals have `role="dialog"` and `aria-labelledby`  
* ✅ All drawers have `role="complementary"`  
* ✅ Status badges have `aria-live="polite"`  
* ✅ Action buttons have descriptive `aria-label`  
* ✅ Form errors announced with `aria-describedby`

### **Safety Mechanisms**

* ✅ No destructive actions execute from table rows  
* ✅ All account changes require modal confirmation  
* ✅ All modals have reason selection (required)  
* ✅ All high-risk actions require DPO approval code  
* ✅ GDPR deletions require legal documentation upload  
* ✅ All actions are audit-logged with admin ID \+ timestamp  
* ✅ Users receive email notifications for all status changes

### **Role-Based Access**

* ✅ Read-Only Admins: See drawers only, no action buttons  
* ✅ Moderators: Can restrict/suspend, no GDPR tools  
* ✅ Finance Admins: Can view data, no account actions  
* ✅ Super Admins: Full access to all features  
* ✅ DPO Admins: Special access to GDPR tools \+ approval codes

---

## **🎯 Success Criteria**

**This Users Page succeeds if:**

1. ✅ Engineers can implement using only existing Vendor Dashboard components  
2. ✅ All destructive actions require 2+ clicks \+ reason code  
3. ✅ Admins complete most tasks in \< 5 clicks  
4. ✅ Zero accidental user suspensions (all require explicit confirmation)  
5. ✅ 100% of actions are logged in audit trail  
6. ✅ GDPR compliance tools meet legal requirements  
7. ✅ Page feels identical to Vendor Dashboard (same visual language)  
8. ✅ No admin confusion about where to find features

---

## **📋 Implementation Phases**

### **Phase 1: Core Table & Drawers (Week 1\)**

* Users page layout with header \+ stats  
* Users table with search \+ filters  
* User Profile Drawer (read-only)  
* Table sorting \+ pagination

### **Phase 2: Account Actions (Week 2\)**

* Account Actions Modal (selector)  
* Restrict Account Modal  
* Suspend Account Modal  
* Restore Account Modal  
* Toast notification system

### **Phase 3: GDPR Tools (Week 3\)**

* GDPR Tools Modal (selector)  
* Export User Data Modal  
* Anonymize Account Modal  
* Delete Account Modal  
* DPO approval code validation  
* Legal documentation upload

### **Phase 4: Polish & Testing (Week 4\)**

* Empty states for tables  
* Loading states for modals  
* Error handling \+ retry  
* Keyboard navigation testing  
* Screen reader testing  
* Role-based UI hiding  
* Audit log integration

---

## **🚫 What NOT to Include**

**Do not implement:**

1. ❌ **Inline editing** \- No edit-in-place for any fields  
2. ❌ **Admin impersonation** \- No "Login as User" feature  
3. ❌ **Message editing** \- Admins can view messages but never edit them  
4. ❌ **Review editing** \- Admins can moderate (hide) but not edit review text  
5. ❌ **Silent actions** \- All actions must notify users (unless explicitly unchecked)  
6. ❌ **Auto-suspensions** \- No automated account suspensions without admin review  
7. ❌ **Bulk actions** \- Not in v1 (too risky for account modifications)  
8. ❌ **Export to other formats** \- Only JSON/CSV for now  
9. ❌ **Custom restriction rules** \- Use predefined restriction types only  
10. ❌ **New design patterns** \- Reuse Vendor Dashboard components exactly

---

## **✅ Final Notes**

**This Users Page:**

* ✅ Reuses 100% of Vendor Dashboard visual design  
* ✅ Separates read (drawers) from write (modals)  
* ✅ Requires explicit confirmation for all destructive actions  
* ✅ Provides GDPR-compliant data export/deletion tools  
* ✅ Logs every action for audit trail  
* ✅ Supports role-based access control  
* ✅ Notifies users of all account changes  
* ✅ Never allows admin impersonation

**Key Principle:**

"The same TradeMatch dashboard — but with controlled, auditable, admin-only power."

---

**Document Version:** 1.0.0  
 **Status:** ✅ Ready for Engineering Implementation  
 **Design Review:** Approved

**END OF SPECIFICATION**

