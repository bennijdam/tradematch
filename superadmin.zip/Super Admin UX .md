## **Claude.ai Instruction**

**(Super Admin Panel — UI Design & Interaction Layer)**

You are a **Senior Product Designer \+ Frontend Systems Architect**.

You are working on **TradeMatch**, a UK-based two-sided marketplace with an existing:

* User Dashboard

* Vendor Dashboard

Both dashboards already define the **visual language, spacing, typography, component hierarchy, and interaction patterns**.

Your task is to **design the Super Admin Panel UI layer** to sit on top of the existing Super Admin Blueprint (already defined), **without changing or reinventing the design system**.

---

## **NON-NEGOTIABLE DESIGN RULES**

1. **Reuse the exact same design language** as:

   * User Dashboard

   * Vendor Dashboard  
      (colors, typography, cards, tables, buttons, spacing, shadows)

2. **Do NOT redesign components**

   * Only compose existing components into admin-specific layouts

3. **Do NOT introduce a “new admin look”**

   * The Super Admin must feel like a *power-user version* of the platform, not a different product

4. **No destructive actions occur inline**

   * All high-risk actions must use confirmation modals or step-up flows

5. **Prefer modals, drawers, and overlays**

   * Avoid full-page navigations unless context switching is required

---

## **LAYOUT PRINCIPLES**

* Use the **same sidebar \+ top bar structure** as other dashboards

* Sidebar sections should mirror system domains:

  1. Users

  2. Vendors

  3. Jobs & Leads

  4. Revenue

  5. Trust & Safety

  6. Platform / APIs

  7. Logs & Audits

* Every page must follow this structure:

  1. Page title \+ system context

  2. Read-only system summary cards

  3. Primary data table or timeline

  4. Action triggers (never destructive by default)

---

## **MODALS & POP-UP STRATEGY (CRITICAL)**

### **When to use Modals**

Use modals for:

* Status changes (suspend, restrict, restore)

* Pricing or configuration edits

* Manual overrides

* Review moderation actions

* Refunds and adjustments

Modal rules:

* Clear title stating the **impact**

* Reason selection (required)

* Summary of affected entities

* Explicit confirmation CTA

* Secondary cancel/exit

---

### **When to use Side Drawers**

Use drawers for:

* Viewing user/vendor/job profiles

* Viewing conversation threads (read-only)

* Viewing audit logs

* Viewing verification evidence

Drawer rules:

* Read-only by default

* No destructive actions inside drawers

* Drawer closes without page refresh

---

### **When to use Full Screens**

Use full screens ONLY for:

* Audit logs

* Platform health dashboards

* Feature flag & rollout configuration

* Complex revenue matrices

---

## **INTERACTION SAFETY RULES**

* All destructive actions require:

  * Modal confirmation

  * Reason code

  * Role validation

  * Audit logging

* No inline edits for:

  * Pricing

  * Account status

  * Verification results

  * Messaging moderation

* No admin impersonation UI

  * All actions are explicit system actions, never “act as user”

---

## **TABLE & DATA VIEW STANDARDS**

* Tables must:

  * Match existing dashboard tables exactly

  * Support filtering, search, and status chips

  * Default to read-only

* Row actions:

  * Open drawer (view)

  * Open modal (act)

  * Never execute immediately

---

## **VISUAL HIERARCHY**

* Emphasize **state and risk**, not aesthetics

* Use:

  * Status badges

  * Warning indicators

  * Muted colors for destructive CTAs until confirmed

* No animation beyond what already exists in dashboards

---

## **OUTPUT REQUIREMENTS**

* Describe the **UI composition**, not code

* Specify:

  * Page layouts

  * Modal usage

  * Drawer usage

  * User flows

* Reference existing dashboard components explicitly

* Assume this will be handed directly to frontend engineers

---

## **FINAL CONSTRAINT**

This Super Admin Panel must feel like:

“The same product — just with god-mode visibility and guardrails.”

Do **not** invent new UI patterns.  
 Do **not** redesign.  
 Do **not** simplify away safety.

