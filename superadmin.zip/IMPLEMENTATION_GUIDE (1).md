# Roles & Permissions Page - Implementation Guide

## Overview
This document explains the Roles & Permissions page for the TradeMatch Super Admin Panel.

## Page Structure

### 1. **Page Header**
- **Title**: "Roles & Permissions"
- **Subtitle**: "Control admin access and permissions across the platform"
- **Action Buttons**:
  - "Create Custom Role" (secondary button)
  - "Add Admin" (primary button)

### 2. **Admin Users Table**
A comprehensive table listing all admin users with:
- **Columns**:
  - Admin (name + email + avatar)
  - Role (badge with icon)
  - Status (Active/Suspended badge)
  - Last Login timestamp
  - Actions (view/edit/suspend buttons)

**Sample Admins**:
1. Sarah Anderson - Super Admin (cannot be edited)
2. James Wilson - Trust & Safety Admin
3. Emma Parker - Finance Admin
4. Michael Thompson - Support Admin
5. Laura Chen - Read-only Admin (suspended)

### 3. **Permission Matrix**
Role-based permission configuration with:

**Role Tabs** (switch between roles):
- Super Admin
- Trust & Safety Admin
- Finance Admin
- Support Admin
- Read-only Admin

**Permission Sections**:

#### A. Core Access
- Access Super Admin Panel
- View Dashboards
- Read-only Mode

#### B. Platform Controls
- Platform Settings ⚠️ High Impact
- Feature Flags
- Kill Switches ⚠️ High Impact
- Maintenance Mode

#### C. Users & Vendors
- View Users
- View Vendors
- Edit Users
- Suspend Users
- Verify Vendors
- Revoke Vendor Access

#### D. Jobs & Leads
- View Jobs
- View Leads
- Pause Lead Delivery
- Override Lead Routing

#### E. Trust & Safety
- View Trust & Safety Queue
- Take Enforcement Actions
- Escalate Incidents
- Resolve Investigations

#### F. Revenue & Billing
- View Revenue Dashboard
- View Stripe Transactions
- Issue Refunds ⚠️ High Impact
- Adjust Pricing
- Manage Subscriptions

#### G. Audit & Logs
- View Audit Logs
- Export Logs
- View System Events

### 4. **Modals**

#### Add Admin Modal
Fields:
- Full Name (required)
- Email Address (required)
- Role dropdown (required)
- Access Scope (optional)
- "Send invitation email immediately" checkbox

Warning: "The new admin must accept the invitation before access is granted. All actions will be logged to Audit Logs."

#### Edit Admin Modal
Fields:
- Current Role dropdown
- Access Scope
- Reason for Change

Warning: "All permission changes will be logged with timestamp and admin who made the change."

#### Suspend Admin Modal
Fields:
- Reason for Suspension (required)
- "Send notification email to admin" checkbox

Danger Alert: "This admin will be immediately logged out and unable to access the Super Admin Panel. This action can be reversed."

#### Create Custom Role Modal
Fields:
- Role Name (required)
- Role Description (required)
- Based on Existing Role dropdown

Info: "After creating this role, you'll be able to configure detailed permissions in the Permission Matrix."

### 5. **Interactive Elements**

#### Toggle Switches
- Default state: depends on role
- Active state: green with glow
- Disabled state: grayed out (for Super Admin restrictions)
- On click: shows toast notification
- Provides haptic feedback via smooth animation

#### Toast Notifications
Appear in top-right corner for:
- Permission updates
- Admin actions (add/edit/suspend)
- Role switches
- Form submissions

Auto-dismiss after 5 seconds with slide-out animation.

## Design Language

### Colors (Dark Theme)
- Background Primary: `#0A0E14`
- Background Card: `#1E2430`
- Accent Primary (Green): `#00E5A0`
- Accent Danger (Red): `#FF4757`
- Accent Warning (Orange): `#FFA726`
- Text Primary: `#FFFFFF`
- Text Secondary: `#9CA3AF`

### Typography
- Font Family: 'Archivo' (sans-serif)
- Monospace: 'Space Mono' (for badges/status)
- Page Title: 32px, weight 800
- Card Title: 20px, weight 700
- Body Text: 14px, weight 400-600

### Spacing
- Page padding: 32px
- Card padding: 24px
- Element gaps: 12-24px
- Border radius: 12-16px (cards), 8px (buttons)

### Shadows
- Small: `0 2px 8px rgba(0, 0, 0, 0.3)`
- Medium: `0 4px 16px rgba(0, 0, 0, 0.4)`
- Large: `0 8px 32px rgba(0, 0, 0, 0.5)`

## Security Considerations

### 1. **Least Privilege Principle**
- Each role has minimum necessary permissions
- Super Admin role cannot be modified or deleted
- All changes require confirmation

### 2. **Audit Trail**
- Every permission change is logged
- Timestamp and acting admin are recorded
- Changes require reason/justification

### 3. **High-Impact Actions**
- Clearly marked with warning badges
- Require additional confirmation
- Limited to specific roles

### 4. **Session Management**
- Suspended admins are immediately logged out
- Active sessions are invalidated
- Email notifications sent for security events

## JavaScript Functionality

### Modal Management
```javascript
function openModal(modalId) {
    // Convert kebab-case to PascalCase for ID
    // Show modal with backdrop
}

function closeModal(modalId) {
    // Hide modal and backdrop
}
```

### Toggle Switch Interaction
```javascript
// Toggle permission on/off
// Show toast notification
// In production: API call to save permission
```

### Role Tab Switching
```javascript
function switchRole(roleId) {
    // Update active tab
    // Load role-specific permissions
    // Show confirmation toast
}
```

### Toast Notifications
```javascript
function showToast(type, title, message) {
    // Create toast element
    // Append to container
    // Auto-remove after 5 seconds
}
```

## Integration Points

### Backend API Endpoints (to be implemented)
- `POST /api/admin/roles/permissions` - Update role permissions
- `POST /api/admin/users` - Add new admin
- `PATCH /api/admin/users/:id` - Edit admin role
- `DELETE /api/admin/users/:id` - Suspend admin
- `POST /api/admin/roles/custom` - Create custom role
- `GET /api/admin/audit-logs` - View audit trail

### Database Schema (recommended)
```sql
-- Roles table
roles (
    id, name, description, is_system_role,
    created_at, updated_at
)

-- Permissions table
permissions (
    id, role_id, resource, action,
    enabled, created_at, updated_at
)

-- Admin users table
admin_users (
    id, name, email, role_id, status,
    last_login, created_at, updated_at
)

-- Audit log table
audit_logs (
    id, admin_id, action, resource,
    old_value, new_value, reason,
    ip_address, created_at
)
```

## File Structure
```
roles-permissions.html (main page - content area only)
├── <style> (matches existing admin panel design system)
├── <div class="main-content"> (page content)
│   ├── Page Header (title + actions)
│   ├── Admin Users Table Card
│   ├── Permissions Matrix Card
│   │   ├── Role Tabs
│   │   └── Permission Sections Grid
│   └── Modals (Add/Edit/Suspend/Create)
└── <script> (minimal vanilla JS for interactions)
```

## Notes for Integration
1. **Sidebar & Top Bar**: Already rendered by parent layout - not included in this file
2. **Theme Toggle**: Inherited from parent, supports both dark/light modes
3. **Responsive**: Desktop-first design (admin-only usage)
4. **Icons**: All SVG icons inlined for performance
5. **No Dependencies**: Pure HTML/CSS/JS, no frameworks required

## Next Steps
1. Wire up API endpoints for actual data persistence
2. Add permission validation middleware
3. Implement audit logging service
4. Create route guards based on permissions
5. Add email notification service for admin actions
6. Implement session invalidation for suspended users
