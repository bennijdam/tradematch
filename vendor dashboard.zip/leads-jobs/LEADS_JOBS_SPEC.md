# Leads & Jobs Pages - Complete Specification

## Overview
Four complete HTML pages for the Leads & Jobs section of TradeMatch Vendor Dashboard.

## Pages to Create

### 1. New Leads (new-leads.html)
**Purpose:** Show newly received leads requiring action
**Features:**
- Lead cards with job details
- Budget range display
- Location (city + postcode)
- Time received
- Status: "New" badge
- CTAs: "View Details" and "Send Quote"
- Low balance warning banner
- Empty state for no leads
- Impression cost display

### 2. Active Quotes (active-quotes.html)
**Purpose:** Track quotes sent and awaiting response
**Features:**
- Quote cards/table
- Quote value range
- Date sent
- Customer response status
- Time remaining indicator
- Status badges: Pending/Viewed/Responded
- CTAs: "View Conversation", "Update Quote"

### 3. Won Jobs (won-jobs.html)
**Purpose:** Confirmed jobs the vendor has won
**Features:**
- Job cards
- Customer name (first name only)
- Location
- Agreed price
- Start date
- Job status: Scheduled/In Progress/Completed
- CTAs: "Message Customer", "Mark as Completed"
- Review request reminders
- Trust messaging

### 4. Archived (archived.html)
**Purpose:** Historical record of past leads and jobs
**Features:**
- Archive rows
- Filters: Date range, Outcome
- Outcomes: Lost/Completed/Expired
- Date closed
- Optional reason display
- Read-only summaries
- Low-emphasis design

## Design System

### Consistent Elements Across All Pages:
- Fixed sidebar navigation (unchanged)
- Top header bar (unchanged)
- Page title and subtitle
- Status badges (color-coded)
- Card/table layouts
- Pagination placeholders
- Loading skeletons
- Empty states
- Toast notifications
- Responsive breakpoints

### Color-Coded Status Badges:
- New: Teal (#00E5A0)
- Pending: Orange (#FFA726)
- Viewed: Blue (#42A5F5)
- Won: Green (#00E5A0)
- Lost: Red (#FF4757)
- Completed: Gray
- Expired: Gray

### UK-Specific Data:
- Postcodes: SW1, E14, M1, G1, etc.
- Cities: London, Manchester, Birmingham, Glasgow
- Trades: Plumber, Electrician, Carpenter, etc.
- Budget ranges in GBP (£)

## Integration Points

### API Endpoints (TODO):
```
GET /api/vendor/leads/new
GET /api/vendor/quotes/active
GET /api/vendor/jobs/won
GET /api/vendor/jobs/archived
POST /api/vendor/quotes/submit
PUT /api/vendor/quotes/{id}
PUT /api/vendor/jobs/{id}/complete
```

### Data Models:
- job_leads table
- quotes table
- impressions_ledger
- notifications

## File Structure
```
leads-jobs/
├── new-leads.html         (Page 1 - New Leads)
├── active-quotes.html     (Page 2 - Active Quotes)
├── won-jobs.html          (Page 3 - Won Jobs)
├── archived.html          (Page 4 - Archived)
└── LEADS_JOBS_SPEC.md    (This file)
```

## Implementation Notes

### Shared CSS Variables:
All pages use existing dashboard variables:
- --bg-primary, --bg-secondary, --bg-tertiary
- --accent-primary, --accent-danger, --accent-warning
- --text-primary, --text-secondary, --text-muted
- --border, --border-hover
- --shadow-sm, --shadow-md, --shadow-lg

### JavaScript Functions:
- switchTab() - Navigation
- viewLead(id) - View lead details
- sendQuote(id) - Quote submission
- updateQuote(id) - Quote updates
- completeJob(id) - Mark job complete
- filterArchive() - Archive filtering
- showToast(message, type) - Notifications

### Mobile Responsive:
- Sidebar collapses to 80px on mobile
- Cards stack vertically
- Tables convert to card layout
- Touch-friendly buttons (44px min)
- Swipeable actions

## Status
- [ ] Page 1: New Leads
- [ ] Page 2: Active Quotes  
- [ ] Page 3: Won Jobs
- [ ] Page 4: Archived
- [ ] ZIP Package
- [ ] Documentation

## Next Steps
1. Create all 4 HTML files
2. Ensure design consistency
3. Add realistic UK data
4. Test responsiveness
5. Create ZIP package
6. Write integration guide
