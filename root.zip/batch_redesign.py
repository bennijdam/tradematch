#!/usr/bin/env python3
"""
TradeMatch Batch Page Redesign Script
Updates all HTML pages with new glassmorphism design and emerald green branding
"""

import os
import re
from pathlib import Path

# New CSS template with glassmorphism and emerald green theme
NEW_STYLES = """
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Source+Serif+4:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --slate: #1A2332;
            --slate-light: #2D3B4E;
            --emerald: #16A34A;
            --emerald-dark: #15803D;
            --gray-50: #F8FAFB;
            --gray-100: #F3F4F6;
            --gray-600: #4B5563;
            --white: #FFFFFF;
            --shadow: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06);
            --shadow-lg: 0 10px 25px rgba(0,0,0,0.08), 0 4px 10px rgba(0,0,0,0.05);
            --glass-bg: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.18);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Manrope', sans-serif;
            color: var(--slate);
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
        }
        
        /* Glassmorphism Header */
        header, nav {
            background: var(--glass-bg);
            border-bottom: 1px solid var(--glass-border);
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.05);
        }
        
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 16px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-family: 'Source Serif 4', serif;
            font-size: 28px;
            font-weight: 700;
            color: var(--slate);
            text-decoration: none;
            letter-spacing: -0.5px;
        }
        
        .logo span {
            color: var(--emerald);
        }
        
        .nav-links {
            display: flex;
            gap: 32px;
            align-items: center;
        }
        
        .nav-links a {
            color: var(--gray-600);
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            transition: color 0.2s;
        }
        
        .nav-links a:hover {
            color: var(--slate);
        }
        
        .btn {
            padding: 12px 28px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            transition: all 0.2s;
            display: inline-block;
            border: none;
            cursor: pointer;
        }
        
        .btn-primary {
            background: var(--emerald);
            color: var(--white);
            box-shadow: 0 1px 2px rgba(22, 163, 74, 0.2);
        }
        
        .btn-primary:hover {
            background: var(--emerald-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(22, 163, 74, 0.25);
        }
        
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, rgba(26, 35, 50, 0.95) 0%, rgba(45, 59, 78, 0.95) 100%),
                        url('https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1600&q=80') center/cover;
            padding: 120px 24px;
            text-align: center;
            color: var(--white);
            position: relative;
            overflow: hidden;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(22, 163, 74, 0.2) 0%, transparent 70%);
            top: -200px;
            right: -200px;
            border-radius: 50%;
            animation: pulse 4s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.2; }
            50% { transform: scale(1.1); opacity: 0.3; }
        }
        
        .hero h1 {
            font-family: 'Source Serif 4', serif;
            font-size: 56px;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 24px;
            letter-spacing: -1px;
            position: relative;
        }
        
        .hero h2 {
            font-size: 20px;
            font-weight: 500;
            margin-bottom: 40px;
            opacity: 0.9;
        }
        
        .hero-cta {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 40px;
            max-width: 500px;
            margin: 0 auto;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .postcode-input {
            width: 100%;
            padding: 14px 16px;
            border: 1.5px solid var(--gray-100);
            border-radius: 8px;
            font-size: 15px;
            margin-bottom: 16px;
            font-family: 'Manrope', sans-serif;
        }
        
        .search-btn {
            width: 100%;
            padding: 14px 32px;
            background: var(--emerald);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .search-btn:hover {
            background: var(--emerald-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(22, 163, 74, 0.25);
        }
        
        /* Content Sections */
        .content-section {
            padding: 100px 24px;
            background: var(--white);
        }
        
        .content-section.alt {
            background: var(--gray-50);
        }
        
        .section-title {
            font-family: 'Source Serif 4', serif;
            font-size: 48px;
            font-weight: 700;
            color: var(--slate);
            margin-bottom: 20px;
            text-align: center;
            letter-spacing: -0.5px;
        }
        
        .section-subtitle {
            font-size: 19px;
            color: var(--gray-600);
            text-align: center;
            max-width: 600px;
            margin: 0 auto 60px;
        }
        
        /* Feature Grid */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 32px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .feature-card {
            background: white;
            border-radius: 16px;
            padding: 32px;
            box-shadow: var(--shadow);
            transition: all 0.3s;
            text-align: center;
        }
        
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }
        
        .feature-icon {
            width: 72px;
            height: 72px;
            background: #E8F5E9;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
            color: var(--emerald);
        }
        
        .feature-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--slate);
        }
        
        .feature-desc {
            color: var(--gray-600);
            font-size: 15px;
            line-height: 1.7;
        }
        
        /* Steps */
        .steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .step {
            text-align: center;
        }
        
        .step-number {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--emerald) 0%, var(--emerald-dark) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 32px;
            font-weight: 800;
            color: var(--white);
            box-shadow: 0 8px 24px rgba(22, 163, 74, 0.25);
        }
        
        .step h3 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 16px;
            color: var(--slate);
        }
        
        .step p {
            color: var(--gray-600);
            line-height: 1.7;
        }
        
        /* Trust Stats */
        .trust-stats {
            display: flex;
            justify-content: center;
            gap: 48px;
            flex-wrap: wrap;
            margin-top: 60px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 36px;
            font-weight: 800;
            color: var(--emerald);
            display: block;
            margin-bottom: 4px;
        }
        
        .stat-label {
            font-size: 14px;
            color: var(--gray-600);
        }
        
        /* Footer */
        footer {
            background: var(--slate);
            color: rgba(255,255,255,0.8);
            padding: 60px 24px 30px;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 48px;
            max-width: 1200px;
            margin: 0 auto 48px;
        }
        
        .footer-brand h3 {
            font-family: 'Source Serif 4', serif;
            font-size: 24px;
            color: var(--white);
            margin-bottom: 16px;
        }
        
        .footer-column h4 {
            color: var(--white);
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .footer-column ul {
            list-style: none;
        }
        
        .footer-column ul li {
            margin-bottom: 12px;
        }
        
        .footer-column a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            font-size: 15px;
            transition: color 0.2s;
        }
        
        .footer-column a:hover {
            color: var(--emerald);
        }
        
        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 30px;
            text-align: center;
            color: rgba(255,255,255,0.6);
            font-size: 14px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero h1 { font-size: 40px; }
            .section-title { font-size: 36px; }
            .nav-links { display: none; }
            .hero { padding: 80px 24px; }
            .content-section { padding: 60px 24px; }
        }
    </style>
"""

# New navigation HTML
NEW_NAV = """
    <header>
        <div class="nav-container">
            <a href="/index.html" class="logo">Trade<span>Match</span></a>
            <div class="nav-links">
                <a href="/how-it-works.html">How It Works</a>
                <a href="/find-tradespeople.html">Find Trades</a>
                <a href="/about.html">About</a>
                <a href="/customer-login.html" class="btn btn-primary">Sign In</a>
            </div>
        </div>
    </header>
"""

# New footer HTML
NEW_FOOTER = """
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <h3>TradeMatch</h3>
                    <p>Connecting homeowners with trusted local tradespeople across the UK.</p>
                </div>
                
                <div class="footer-column">
                    <h4>For Customers</h4>
                    <ul>
                        <li><a href="/how-it-works.html">How It Works</a></li>
                        <li><a href="/quote-engine.html">Post a Job</a></li>
                        <li><a href="/find-tradespeople.html">Find Trades</a></li>
                        <li><a href="/help.html">Help Center</a></li>
                    </ul>
                </div>
                
                <div class="footer-column">
                    <h4>For Tradespeople</h4>
                    <ul>
                        <li><a href="/vendor-register.html">Join as a Trade</a></li>
                        <li><a href="/vendor-login.html">Trade Login</a></li>
                        <li><a href="/vendor-dashboard.html">Dashboard</a></li>
                    </ul>
                </div>
                
                <div class="footer-column">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="/about.html">About Us</a></li>
                        <li><a href="/contact.html">Contact</a></li>
                        <li><a href="/terms.html">Terms</a></li>
                        <li><a href="/privacy.html">Privacy</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                © 2026 TradeMatch. All rights reserved.
            </div>
        </div>
    </footer>
"""

def update_html_file(file_path):
    """Update a single HTML file with new design"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Skip if already updated
        if 'var(--emerald)' in content:
            print(f"✓ Already updated: {file_path}")
            return
        
        # Remove old style tags and links
        content = re.sub(r'<link[^>]*stylesheet[^>]*>', '', content)
        content = re.sub(r'<style>.*?</style>', '', content, flags=re.DOTALL)
        
        # Insert new styles before </head>
        content = content.replace('</head>', f'{NEW_STYLES}</head>')
        
        # Update navigation if exists
        content = re.sub(r'<nav>.*?</nav>', NEW_NAV, content, flags=re.DOTALL)
        content = re.sub(r'<header>.*?</header>', NEW_NAV, content, flags=re.DOTALL)
        
        # Update footer if exists
        content = re.sub(r'<footer>.*?</footer>', NEW_FOOTER, content, flags=re.DOTALL)
        
        # Add navigation if missing
        if '<header>' not in content and '<nav>' not in content:
            content = content.replace('<body>', f'<body>\n{NEW_NAV}')
        
        # Add footer if missing
        if '<footer>' not in content:
            content = content.replace('</body>', f'{NEW_FOOTER}\n</body>')
        
        # Update color references
        color_replacements = {
            '#FF385C': 'var(--emerald)',
            '#D50027': 'var(--emerald-dark)',
            '#00B4D8': 'var(--emerald)',
            'rgb(255, 56, 92)': 'rgb(22, 163, 74)',
            'rgba(255, 56, 92': 'rgba(22, 163, 74'
        }
        
        for old, new in color_replacements.items():
            content = content.replace(old, new)
        
        # Write updated content
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"✓ Updated: {file_path}")
        
    except Exception as e:
        print(f"✗ Error updating {file_path}: {str(e)}")

def process_directory(directory):
    """Process all HTML files in a directory"""
    html_files = Path(directory).rglob('*.html')
    count = 0
    
    for file_path in html_files:
        update_html_file(str(file_path))
        count += 1
    
    return count

if __name__ == "__main__":
    print("🎨 TradeMatch Batch Redesign Starting...")
    print("=" * 50)
    
    # Process frontend pages
    print("\n📁 Processing frontend pages...")
    frontend_count = process_directory('./frontend')
    
    # Process SEO pages
    print("\n📁 Processing SEO pages...")
    seo_count = process_directory('./seo-pages')
    
    print("\n" + "=" * 50)
    print(f"✅ Complete! Updated {frontend_count + seo_count} pages")
    print(f"   Frontend: {frontend_count} pages")
    print(f"   SEO: {seo_count} pages")
